import { findHotspot, matchInstruction, type Hotspot } from './samples';

/**
 * Phase 0 适配器隔离：模拟与真实 AI 共用同一接口。
 * Phase 1 时 MockMask → SAM、MockEdit → Image Edit，只替换实现，不改调用方。
 */

export interface MaskResult {
  label: string;
  bbox: { x: number; y: number; w: number; h: number };
  maskUri: string | null; // Phase 0 为预置热点，无像素级遮罩文件
  source: 'mock';
}

export interface SelectorAdapter {
  selectObject(assetUri: string, hotspotId: string): Promise<MaskResult>;
}

export class MockMask implements SelectorAdapter {
  async selectObject(_assetUri: string, hotspotId: string): Promise<MaskResult> {
    const found = findHotspot(hotspotId);
    if (!found) throw new Error(`unknown hotspot: ${hotspotId}`);
    // 模拟分割延迟，保持与真实调用一致的异步形态
    await new Promise((r) => setTimeout(r, 300));
    return {
      label: found.hotspot.label,
      bbox: found.hotspot.bbox,
      maskUri: null,
      source: 'mock',
    };
  }
}

export interface EditRequest {
  hotspotId: string;
  prompt: string;
  promptType: 'quick' | 'text';
}

export interface EditResult {
  resultUri: string;
  modelVersion: string; // mock-edit-v1；真实模型接入后替换
  simulated: true;
}

export interface EditAdapter {
  edit(req: EditRequest): Promise<EditResult>;
}

export class MockEdit implements EditAdapter {
  async edit(req: EditRequest): Promise<EditResult> {
    const found = findHotspot(req.hotspotId);
    if (!found) throw new Error(`unknown hotspot: ${req.hotspotId}`);
    const hotspot: Hotspot = found.hotspot;
    const inst =
      req.promptType === 'quick'
        ? hotspot.instructions.find((i) => i.text === req.prompt) ?? matchInstruction(hotspot, req.prompt)
        : matchInstruction(hotspot, req.prompt);
    return { resultUri: inst.resultImage, modelVersion: 'mock-edit-v1', simulated: true };
  }
}

export const selectorAdapter: SelectorAdapter = new MockMask();
export const editAdapter: EditAdapter = new MockEdit();

/* ---------------- Phase 1：按 AI_PROVIDER 选择 Mock / 真实链路 ----------------
 * - AI_PROVIDER=mock（默认）：上面两个 Mock 实例，行为与 Phase 0 完全一致。
 * - AI_PROVIDER=aliyun（国内默认推荐）：阿里云图像分割点选 + 火山即梦改图（lib/real_adapters.ts）。
 * - AI_PROVIDER=seedream|gemini：真实 AI 链路（lib/real_adapters.ts），点选走 Replicate SAM（已废弃）。
 *   key 缺失时抛 MissingApiKeyError，绝不静默回退 Mock。
 */
export { readProvider as aiProvider } from './real_adapters';
export type { AiProvider } from './real_adapters';
