import type { DatabaseSync } from 'node:sqlite';
import { nowIso } from './db';

/**
 * 事件字典（P0）与隐私最小化：
 * - 只记录类型、长度、任务标识；不记录原始图片、完整提示词、可识别个人信息。
 * - prompt 只记录 prompt_type 与 prompt_length。
 */

export const EVENT_NAMES = [
  'demo_started',
  'asset_ready',
  'selection_confirmed',
  'edit_submitted',
  'edit_completed',
  'edit_failed',
  'compare_used',
  'second_edit_started',
] as const;

export type EventName = (typeof EVENT_NAMES)[number];

export interface DemoEvent {
  id: number;
  name: string;
  session_id: string;
  project_id: string | null;
  job_id: string | null;
  ts: string;
  props: Record<string, unknown> | null;
}

export function recordEvent(
  db: DatabaseSync,
  input: {
    name: EventName;
    session_id: string;
    project_id?: string | null;
    job_id?: string | null;
    props?: Record<string, unknown>;
  }
): DemoEvent {
  const ts = nowIso();
  const res = db
    .prepare(`INSERT INTO event (name, session_id, project_id, job_id, ts, props) VALUES (?,?,?,?,?,?)`)
    .run(
      input.name,
      input.session_id,
      input.project_id ?? null,
      input.job_id ?? null,
      ts,
      input.props ? JSON.stringify(input.props) : null
    );
  return {
    id: Number(res.lastInsertRowid),
    name: input.name,
    session_id: input.session_id,
    project_id: input.project_id ?? null,
    job_id: input.job_id ?? null,
    ts,
    props: input.props ?? null,
  };
}

export function listEvents(db: DatabaseSync, sessionId: string, limit = 100): DemoEvent[] {
  const rows = db
    .prepare(`SELECT * FROM event WHERE session_id = ? ORDER BY id DESC LIMIT ?`)
    .all(sessionId, limit) as (Omit<DemoEvent, 'props'> & { props: string | null })[];
  return rows.map((r) => ({ ...r, props: r.props ? JSON.parse(r.props) : null }));
}
