/**
 * lib/oss.ts — 阿里云 OSS 最小客户端（自用 demo）
 *
 * 背景：阿里云图像分割（SegmentCommonImage）要求 ImageURL 必须是 OSS 公网地址，
 * 本地 public/ 下的图片（用户上传、自带样板）需要先同步到 OSS。
 * 本模块在点选分割时被调用：有则直接用，没有则上传，保证幂等。
 *
 * 签名：OSS Signature V1（HMAC-SHA1），与 imageseg RPC 共用同一对 RAM AccessKey。
 * bucket 要求：华东2（上海）、公共读、已关闭"阻止公共访问"。
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const OSS_HOST = 'oss-cn-shanghai.aliyuncs.com';

const MIME_BY_EXT: Record<string, string> = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
};

interface OssConfig {
  keyId: string;
  keySecret: string;
  base: string;
  bucket: string;
}

function ossConfig(): OssConfig {
  const keyId = process.env.ALIYUN_ACCESS_KEY_ID?.trim();
  const keySecret = process.env.ALIYUN_ACCESS_KEY_SECRET?.trim();
  const base = process.env.ALIYUN_IMAGE_BASE_URL?.trim().replace(/\/+$/, '');
  if (!keyId || !keySecret) {
    throw new Error('缺少 ALIYUN_ACCESS_KEY_ID / ALIYUN_ACCESS_KEY_SECRET（去阿里云 RAM 控制台创建）');
  }
  if (!base) {
    throw new Error('缺少 ALIYUN_IMAGE_BASE_URL（如 https://<bucket>.oss-cn-shanghai.aliyuncs.com）');
  }
  const m = base.match(/^https:\/\/([a-z0-9][a-z0-9-]{1,61}[a-z0-9])\.oss-cn-shanghai\.aliyuncs\.com$/);
  if (!m) throw new Error(`ALIYUN_IMAGE_BASE_URL 格式不支持: ${base}`);
  return { keyId, keySecret, base, bucket: m[1] };
}

/** OSS Signature V1：返回带 Authorization 的 headers。 */
function signV1(
  method: string,
  bucket: string,
  objectKey: string,
  subResource: string,
  extraHeaders: Record<string, string>,
  keyId: string,
  keySecret: string
): Record<string, string> {
  const date = new Date().toUTCString();
  const headers: Record<string, string> = { ...extraHeaders, Date: date };
  const ossHeaders = Object.keys(headers)
    .filter((k) => k.toLowerCase().startsWith('x-oss-'))
    .sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()))
    .map((k) => `${k.toLowerCase()}:${headers[k].trim()}`)
    .join('\n');
  const canonHeaders = ossHeaders ? ossHeaders + '\n' : '';
  let resource = `/${bucket}/`;
  if (objectKey) resource += objectKey;
  if (subResource) resource += `?${subResource}`;
  const stringToSign =
    `${method}\n${headers['Content-MD5'] || ''}\n${headers['Content-Type'] || ''}\n` +
    `${date}\n${canonHeaders}${resource}`;
  const signature = crypto.createHmac('sha1', keySecret).update(stringToSign, 'utf8').digest('base64');
  headers['Authorization'] = `OSS ${keyId}:${signature}`;
  return headers;
}

function objectUrl(cfg: OssConfig, key: string): string {
  return `https://${cfg.bucket}.${OSS_HOST}/${key}`;
}

/** HEAD 检查对象是否已存在。 */
export async function ossObjectExists(key: string): Promise<boolean> {
  const cfg = ossConfig();
  const headers = signV1('HEAD', cfg.bucket, key, '', {}, cfg.keyId, cfg.keySecret);
  const r = await fetch(objectUrl(cfg, key), { method: 'HEAD', headers });
  if (r.status === 200) return true;
  if (r.status === 404) return false;
  throw new Error(`OSS HEAD 失败: HTTP ${r.status}（key=${key}）`);
}

/** PUT 上传对象（覆盖写，幂等）。 */
export async function ossPutObject(key: string, body: Buffer, contentType: string): Promise<void> {
  const cfg = ossConfig();
  const headers = signV1('PUT', cfg.bucket, key, '', { 'Content-Type': contentType }, cfg.keyId, cfg.keySecret);
  const r = await fetch(objectUrl(cfg, key), { method: 'PUT', headers, body: new Uint8Array(body) });
  if (r.status !== 200) {
    const text = await r.text().catch(() => '');
    throw new Error(`OSS 上传失败: HTTP ${r.status} ${text.slice(0, 200)}（key=${key}）`);
  }
}

/**
 * 把本地 public/ 下的图片同步到 OSS，返回公网可访问 URL。
 * - http(s) 地址：直接返回（已是公网）。
 * - data: URI：抛错（阿里云分割不支持）。
 * - 本地 uri：public/ 下必须有该文件；OSS 上没有才上传。
 */
export async function ensureOssPublicUrl(assetUri: string): Promise<string> {
  if (/^https?:\/\//i.test(assetUri)) return assetUri;
  if (assetUri.startsWith('data:')) {
    throw new Error(
      '阿里云图像分割要求 ImageURL 为公网可访问的图片地址，data: URI 无法使用；' +
        '请上传文件后配置 ALIYUN_IMAGE_BASE_URL，或直接使用 http(s) 图片地址'
    );
  }
  const cfg = ossConfig();
  const rel = assetUri.replace(/^\/+/, '');
  const publicRoot = path.join(process.cwd(), 'public');
  const localPath = path.join(publicRoot, rel);
  if (!localPath.startsWith(publicRoot + path.sep)) throw new Error(`非法 assetUri: ${assetUri}`);
  if (!fs.existsSync(localPath)) {
    throw new Error(`本地图片不存在: ${assetUri}，无法同步到 OSS`);
  }
  const key = rel.split(path.sep).join('/');
  if (!(await ossObjectExists(key))) {
    const ext = path.extname(rel).toLowerCase();
    const contentType = MIME_BY_EXT[ext] || 'application/octet-stream';
    await ossPutObject(key, fs.readFileSync(localPath), contentType);
  }
  return `${cfg.base}/${key}`;
}
