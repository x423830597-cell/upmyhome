import type { DatabaseSync } from 'node:sqlite';
import { getDb, newId, nowIso } from './db';
import { appendLedger } from './ledger';
import { recordEvent } from './events';
import { editAdapter, aiProvider } from './adapters';
import { getRealEditAdapter, realModelVersion } from './real_adapters';

/**
 * 任务状态机：
 *   created → charged → processing → succeeded
 *   失败路径：charged / processing → failed → refunded
 * 同一 idempotency_key 只能产生一笔 charge。
 *
 * Phase 0 用进程内 setTimeout 驱动流转（无外部队列）；Phase 1 替换为真实队列 worker。
 */

export const TRANSITIONS: Record<string, string[]> = {
  created: ['charged'],
  charged: ['processing', 'failed'],
  processing: ['succeeded', 'failed'],
  failed: ['refunded'],
  succeeded: [],
  refunded: [],
};

export interface EditJob {
  id: string;
  selection_id: string;
  prompt: string;
  prompt_type: string;
  prompt_length: number;
  status: string;
  model_version: string;
  points_cost: number;
  actual_ai_cost: number;
  latency_ms: number | null;
  error_class: string | null;
  result_uri: string | null;
  idem_key: string;
  created_at: string;
  updated_at: string;
}

// 演示加速：失败后 5 秒自动退点（计划要求 1 分钟内）
export const REFUND_DELAY_MS = 5000;
const QUEUE_DELAY_MS = 2500; // charged → processing（展示“排队中”）
const PROCESS_DELAY_MS = 3500; // processing → 终态（展示“生成中”）

export type ForceFailMode = 'off' | 'error' | 'timeout';

export function getJob(db: DatabaseSync, id: string): EditJob | null {
  const row = db.prepare(`SELECT * FROM edit_job WHERE id = ?`).get(id) as EditJob | undefined;
  return row ?? null;
}

export function getJobByIdemKey(db: DatabaseSync, idemKey: string): EditJob | null {
  const row = db.prepare(`SELECT * FROM edit_job WHERE idem_key = ?`).get(idemKey) as EditJob | undefined;
  return row ?? null;
}

export function transitionJob(db: DatabaseSync, id: string, to: string): EditJob {
  const job = getJob(db, id);
  if (!job) throw new Error('job not found');
  const allowed = TRANSITIONS[job.status] ?? [];
  if (!allowed.includes(to)) {
    throw new Error(`illegal transition: ${job.status} -> ${to}`);
  }
  const ts = nowIso();
  db.prepare(`UPDATE edit_job SET status = ?, updated_at = ? WHERE id = ?`).run(to, ts, id);
  return { ...job, status: to, updated_at: ts };
}

export interface CreateJobInput {
  selection_id: string;
  session_id: string;
  hotspot_id: string;
  prompt: string;
  prompt_type: 'quick' | 'text';
  points_cost: number;
  idem_key: string;
  force_fail?: ForceFailMode;
}

/** 创建任务并同步预扣点（created → charged）。幂等：idem_key 已存在则直接返回原任务。 */
export function createAndChargeJob(db: DatabaseSync, input: CreateJobInput): { job: EditJob; created: boolean } {
  const existing = getJobByIdemKey(db, input.idem_key);
  if (existing) return { job: existing, created: false };

  const id = newId();
  const ts = nowIso();
  // Phase 1：model_version 跟随 AI_PROVIDER；mock 走 mock-edit-v1，真实链路走真实模型名。
  // 真实链路的 key 缺失等问题在 worker 执行时抛错，走失败→退点路径（诚实失败，不回退 Mock）。
  const modelVersion = aiProvider() === 'mock' ? 'mock-edit-v1' : realModelVersion();
  db.prepare(
    `INSERT INTO edit_job
     (id, selection_id, prompt, prompt_type, prompt_length, status, model_version, points_cost, actual_ai_cost, latency_ms, error_class, result_uri, idem_key, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    id,
    input.selection_id,
    input.prompt,
    input.prompt_type,
    [...input.prompt].length,
    'created',
    modelVersion,
    input.points_cost,
    0, // 真实 AI 成本在 worker 成功后回填；Mock 任务恒为 0
    null,
    null,
    null,
    input.idem_key,
    ts,
    ts
  );
  let job = getJob(db, id)!;
  // 预扣点：幂等追加，同一 idem_key 只扣一笔
  appendLedger(db, {
    session_id: input.session_id,
    delta: -input.points_cost,
    reason: 'charge',
    job_id: id,
    idem_key: `charge:${input.idem_key}`,
  });
  job = transitionJob(db, id, 'charged');
  recordEvent(db, {
    name: 'edit_submitted',
    session_id: input.session_id,
    job_id: id,
    props: { points: input.points_cost, prompt_type: input.prompt_type, prompt_length: [...input.prompt].length },
  });
  enqueueJob(id, input.hotspot_id, input.prompt, input.prompt_type, input.session_id, input.force_fail ?? 'off');
  return { job, created: true };
}

/** 进程内 worker：驱动 charged → processing → succeeded/failed →(refund)→ refunded */
function enqueueJob(
  jobId: string,
  hotspotId: string,
  prompt: string,
  promptType: 'quick' | 'text',
  sessionId: string,
  forceFail: ForceFailMode
) {
  const startedAt = Date.now();
  setTimeout(() => {
    const db = getDb();
    const job = getJob(db, jobId);
    if (!job || job.status !== 'charged') return;
    transitionJob(db, jobId, 'processing');

    setTimeout(async () => {
      const db2 = getDb();
      const job2 = getJob(db2, jobId);
      if (!job2 || job2.status !== 'processing') return;
      const latency = Date.now() - startedAt;

      if (forceFail !== 'off') {
        const errorClass = forceFail === 'timeout' ? 'timeout' : 'mock_error';
        db2.prepare(`UPDATE edit_job SET error_class = ?, latency_ms = ?, updated_at = ? WHERE id = ?`)
          .run(errorClass, latency, nowIso(), jobId);
        transitionJob(db2, jobId, 'failed');
        // 演示加速：REFUND_DELAY_MS 后自动退点，再记录 edit_failed（携带 refunded:true）
        setTimeout(() => {
          const db3 = getDb();
          const job3 = getJob(db3, jobId);
          if (!job3 || job3.status !== 'failed') return;
          const ts = nowIso();
          appendLedger(db3, {
            session_id: sessionId,
            delta: job3.points_cost,
            reason: 'refund',
            job_id: jobId,
            idem_key: `refund:${jobId}`,
          });
          transitionJob(db3, jobId, 'refunded');
          recordEvent(db3, {
            name: 'edit_failed',
            session_id: sessionId,
            job_id: jobId,
            props: { error_class: errorClass, refunded: true, latency_ms: latency },
          });
        }, REFUND_DELAY_MS);
        return;
      }

      try {
        // Phase 1：按 job 创建时的 model_version 选择 Mock / 真实链路。
        // 状态机（processing → succeeded / failed → refunded）与 Mock 路径完全一致。
        if (job2.model_version === 'mock-edit-v1') {
          const result = await editAdapter.edit({ hotspotId, prompt, promptType });
          const db4 = getDb();
          db4.prepare(`UPDATE edit_job SET result_uri = ?, latency_ms = ?, updated_at = ? WHERE id = ?`)
            .run(result.resultUri, latency, nowIso(), jobId);
          transitionJob(db4, jobId, 'succeeded');
          recordEvent(db4, {
            name: 'edit_completed',
            session_id: sessionId,
            job_id: jobId,
            props: { latency_ms: latency, actual_ai_cost: 0 },
          });
        } else {
          // 真实链路：从 selection 取原图 uri + mask + label；key 缺失时抛错 → failed → 自动退点。
          const db4 = getDb();
          const sel = db4.prepare(
            `SELECT s.label, s.mask_asset_id, a.uri AS asset_uri
             FROM selection s JOIN asset a ON a.id = s.asset_id WHERE s.id = ?`
          ).get(job2.selection_id) as
            | { label: string; mask_asset_id: string | null; asset_uri: string }
            | undefined;
          if (!sel) throw new Error(`selection not found: ${job2.selection_id}`);
          const realEdit = getRealEditAdapter();
          const result = await realEdit.edit({
            imageUri: sel.asset_uri,
            maskUri: sel.mask_asset_id,
            prompt,
            label: sel.label,
            outputId: jobId,
          });
          db4.prepare(
            `UPDATE edit_job SET result_uri = ?, model_version = ?, actual_ai_cost = ?, latency_ms = ?, updated_at = ? WHERE id = ?`
          ).run(result.resultUri, result.modelVersion, result.costCny, latency, nowIso(), jobId);
          transitionJob(db4, jobId, 'succeeded');
          recordEvent(db4, {
            name: 'edit_completed',
            session_id: sessionId,
            job_id: jobId,
            props: {
              latency_ms: latency,
              actual_ai_cost: result.costCny,
              model_version: result.modelVersion,
              mask_sent: result.maskSent,
            },
          });
        }
      } catch (err) {
        const db4 = getDb();
        const errorClass = 'adapter_error';
        db4.prepare(`UPDATE edit_job SET error_class = ?, latency_ms = ?, updated_at = ? WHERE id = ?`)
          .run(errorClass, latency, nowIso(), jobId);
        transitionJob(db4, jobId, 'failed');
        setTimeout(() => {
          const db5 = getDb();
          const job5 = getJob(db5, jobId);
          if (!job5 || job5.status !== 'failed') return;
          appendLedger(db5, {
            session_id: sessionId,
            delta: job5.points_cost,
            reason: 'refund',
            job_id: jobId,
            idem_key: `refund:${jobId}`,
          });
          transitionJob(db5, jobId, 'refunded');
          recordEvent(db5, {
            name: 'edit_failed',
            session_id: sessionId,
            job_id: jobId,
            props: { error_class: errorClass, refunded: true, latency_ms: latency },
          });
        }, REFUND_DELAY_MS);
      }
    }, PROCESS_DELAY_MS);
  }, QUEUE_DELAY_MS);
}
