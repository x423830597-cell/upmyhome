// 客户端/服务端共享常量（不得引入 node:sqlite 等服务端依赖）
export const POINTS_PER_EDIT = 5;
export const NEW_SESSION_GRANT = 30;
