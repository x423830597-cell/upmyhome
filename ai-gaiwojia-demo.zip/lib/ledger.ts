import type { DatabaseSync } from 'node:sqlite';
import { nowIso } from './db';

/**
 * 点数账本：只追加、不直接改余额。余额 = 该 session 所有流水 delta 之和。
 * reason: grant_new_session（新会话赠送） / charge（扣点） / refund（退款）
 */

export interface LedgerEntry {
  id: number;
  session_id: string;
  delta: number;
  reason: string;
  job_id: string | null;
  idem_key: string | null;
  created_at: string;
}

export function getBalance(db: DatabaseSync, sessionId: string): number {
  const row = db
    .prepare(`SELECT COALESCE(SUM(delta), 0) AS balance FROM point_ledger WHERE session_id = ?`)
    .get(sessionId) as { balance: number };
  return row.balance;
}

/** 幂等追加：同一 idem_key 只记一笔（UNIQUE 约束兜底）。 */
export function appendLedger(
  db: DatabaseSync,
  entry: { session_id: string; delta: number; reason: string; job_id?: string | null; idem_key?: string | null }
): LedgerEntry | null {
  if (entry.idem_key) {
    const exists = db.prepare(`SELECT id FROM point_ledger WHERE idem_key = ?`).get(entry.idem_key);
    if (exists) return null;
  }
  const ts = nowIso();
  const res = db
    .prepare(
      `INSERT INTO point_ledger (session_id, delta, reason, job_id, idem_key, created_at) VALUES (?,?,?,?,?,?)`
    )
    .run(entry.session_id, entry.delta, entry.reason, entry.job_id ?? null, entry.idem_key ?? null, ts);
  return {
    id: Number(res.lastInsertRowid),
    session_id: entry.session_id,
    delta: entry.delta,
    reason: entry.reason,
    job_id: entry.job_id ?? null,
    idem_key: entry.idem_key ?? null,
    created_at: ts,
  };
}

export function listLedger(db: DatabaseSync, sessionId: string, limit = 50): LedgerEntry[] {
  return db
    .prepare(`SELECT * FROM point_ledger WHERE session_id = ? ORDER BY id DESC LIMIT ?`)
    .all(sessionId, limit) as unknown as LedgerEntry[];
}
