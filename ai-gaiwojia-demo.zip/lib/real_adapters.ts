/**
 * Phase 1 真实 AI 适配器（创始人自用 demo）。
 *
 * - AliyunSelectorAdapter（国内默认推荐）：按点击坐标 {x, y}（相对坐标 0-1）调
 *   阿里云视觉智能开放平台图像分割 SegmentCommonImage，返回的透明 PNG 前景经
 *   alpha 通道转二值 mask + 连通域分析取点击点所在实例，落盘 public/masks + bbox。
 * - RealSelectorAdapter：Replicate SAM。[已废弃]不再推荐（需外币支付方式），
 *   仅为兼容保留；新链路请用 AI_PROVIDER=aliyun。
 * - SeedreamEditAdapter：火山方舟 Seedream，参考图 + 提示词；
 *   mask 若 API 支持则传（AI_MASK_MODE=auto 时尝试），不支持则降级纯提示词并明示日志。
 * - GeminiEditAdapter：Gemini 2.5 Flash Image（二代），参考图 + 提示词（无 mask 通道）。
 *
 * 约束：
 * - key 只从环境变量读；缺失时抛 MissingApiKeyError，绝不静默回退 Mock。
 * - 本文件只写调用逻辑、未做网络测试；注释中以 [待核对] 标出所有
 *   “等真 key 到了、首次运行前必须人工核对”的口径不确定项。
 * - Mock 适配器保留在 lib/adapters.ts 不动；AI_PROVIDER=mock（默认）时走 Mock。
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { inflateSync, deflateSync } from 'node:zlib';
import { ensureOssPublicUrl } from './oss';

/* ---------------- 配置与成本 ---------------- */

export type AiProvider = 'mock' | 'seedream' | 'gemini' | 'aliyun';

export function readProvider(): AiProvider {
  const v = (process.env.AI_PROVIDER ?? 'mock').trim().toLowerCase();
  return v === 'seedream' || v === 'gemini' || v === 'aliyun' ? v : 'mock';
}

export type MaskMode = 'auto' | 'off';

export function readMaskMode(): MaskMode {
  return (process.env.AI_MASK_MODE ?? 'auto').trim().toLowerCase() === 'off' ? 'off' : 'auto';
}

/** Replicate SAM 模型，格式 owner/name。[待核对]社区模型可能下线/改版，以模型页为准。 */
export const SAM_MODEL = process.env.REPLICATE_SAM_MODEL?.trim() || 'cbx1/sam-vit-h';
/** Seedream 模型 ID。[待核对]以火山方舟控制台实际模型 ID 为准（如 doubao-seedream-4-0-xxxxx）。 */
export const SEEDREAM_MODEL = process.env.SEEDREAM_MODEL?.trim() || 'seedream-5-0';
/**
 * 方舟 API 域名。默认官方域名；沙盒出口代理下用 volces.com 服务域名才可达，
 * 本地 .env.local 可设 ARK_BASE_URL=https://ark.cn-beijing.volces.com 覆盖。
 */
export const ARK_BASE_URL = (process.env.ARK_BASE_URL?.trim() || 'https://ark.cn-beijing.volcengine.com').replace(/\/+$/, '');
/** Gemini 模型。[待核对]一代 2026-10-02 退役，默认二代；以 AI Studio 文档为准。 */
export const GEMINI_MODEL = process.env.GEMINI_MODEL?.trim() || 'gemini-2.5-flash-image';

// 成本估算（人民币/次），来自预研报告公开价目（2026-09-23），记入 edit_job.actual_ai_cost。
export const COST_SAM_CNY = 0.01; // Replicate SAM 约 $0.00055–0.0016/次 ≈ ¥0.004–0.012，取整估算。[已废弃链路]
export const COST_SEEDREAM_CNY = 0.22; // Seedream 5.0 公开价 ¥0.22/张
export const COST_GEMINI_CNY = 0; // 免费额度内
// [待核对]阿里云图像分割 SegmentCommonImage 单价未在公开文档中查到，此处 0.03 为占位估算；
// 首次配置前请以视觉智能开放平台控制台“计费介绍”页为准更新。调用失败不计费（官方文档确认）。
export const COST_ALIYUN_SEGMENT_CNY = 0.03;

export class MissingApiKeyError extends Error {
  constructor(envName: string, hint: string) {
    super(`缺少环境变量 ${envName}：${hint}。自用 demo 要求诚实失败，不回退 Mock。`);
    this.name = 'MissingApiKeyError';
  }
}

function requireEnv(name: string, hint: string): string {
  const v = process.env[name]?.trim();
  if (!v) throw new MissingApiKeyError(name, hint);
  return v;
}

/* ---------------- 通用小工具 ---------------- */

function ensureDir(dir: string): void {
  fs.mkdirSync(dir, { recursive: true });
}

function publicFilePath(publicUri: string): string {
  // '/masks/xxx.png' -> <cwd>/public/masks/xxx.png；防目录穿越
  const rel = publicUri.replace(/^\/+/, '');
  const p = path.join(process.cwd(), 'public', rel);
  if (!p.startsWith(path.join(process.cwd(), 'public'))) throw new Error(`非法 uri: ${publicUri}`);
  return p;
}

const MIME_BY_EXT: Record<string, string> = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
};

async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs: number): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

interface ImageBytes {
  bytes: Buffer;
  mime: string;
}

/** 解析 assetUri：支持 http(s) URL、data: URI、public 下相对路径（'/samples/a.jpg'）。 */
async function resolveImageBytes(uri: string): Promise<ImageBytes> {
  if (uri.startsWith('data:')) {
    const m = uri.match(/^data:([^;,]+)(;base64)?,([\s\S]*)$/);
    if (!m) throw new Error('无法解析 data URI');
    return { bytes: Buffer.from(m[3], m[2] ? 'base64' : 'utf-8'), mime: m[1] };
  }
  if (/^https?:\/\//i.test(uri)) {
    const r = await fetchWithTimeout(uri, {}, 60_000);
    if (!r.ok) throw new Error(`下载图片失败: HTTP ${r.status}`);
    const mime = r.headers.get('content-type')?.split(';')[0] ?? 'image/jpeg';
    return { bytes: Buffer.from(await r.arrayBuffer()), mime };
  }
  const filePath = publicFilePath(uri);
  if (!fs.existsSync(filePath)) throw new Error(`图片文件不存在: ${uri}`);
  const ext = path.extname(filePath).toLowerCase();
  return { bytes: fs.readFileSync(filePath), mime: MIME_BY_EXT[ext] ?? 'image/jpeg' };
}

function toDataUri(bytes: Buffer, mime: string): string {
  return `data:${mime};base64,${bytes.toString('base64')}`;
}

async function downloadToFile(url: string, destPublicUri: string, timeoutMs: number): Promise<void> {
  const r = await fetchWithTimeout(url, {}, timeoutMs);
  if (!r.ok) throw new Error(`下载结果图失败: HTTP ${r.status}`);
  const dest = publicFilePath(destPublicUri);
  ensureDir(path.dirname(dest));
  fs.writeFileSync(dest, Buffer.from(await r.arrayBuffer()));
}

/* ---------------- 最小 PNG 解析（从 SAM mask 反推 bbox，无第三方依赖） ---------------- */

export interface PngMask {
  w: number;
  h: number;
  /** 1 = 前景，0 = 背景 */
  alpha: Uint8Array;
}

/** 只支持 8bit、colorType 0/2/4/6；解析失败返回 null（调用方用点击位置兜底）。 */
export function parsePngMask(png: Buffer): PngMask | null {
  try {
    const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
    if (!png.subarray(0, 8).equals(SIG)) return null;
    let w = 0;
    let h = 0;
    let bitDepth = 0;
    let colorType = 0;
    const idat: Buffer[] = [];
    let off = 8;
    while (off + 8 <= png.length) {
      const len = png.readUInt32BE(off);
      const type = png.toString('ascii', off + 4, off + 8);
      const data = png.subarray(off + 8, off + 8 + len);
      if (type === 'IHDR') {
        w = data.readUInt32BE(0);
        h = data.readUInt32BE(4);
        bitDepth = data[8];
        colorType = data[9];
      } else if (type === 'IDAT') {
        idat.push(data);
      } else if (type === 'IEND') {
        break;
      }
      off += 12 + len;
    }
    if (bitDepth !== 8 || ![0, 2, 4, 6].includes(colorType) || w === 0 || h === 0) return null;
    const channels = colorType === 0 || colorType === 4 ? 1 : 3;
    const hasAlpha = colorType === 4 || colorType === 6;
    const bpp = channels + (hasAlpha ? 1 : 0);
    const raw = inflateSync(Buffer.concat(idat));
    const stride = w * bpp;
    const alpha = new Uint8Array(w * h);
    let p = 0;
    const prev = Buffer.alloc(stride);
    for (let y = 0; y < h; y++) {
      const filter = raw[p++];
      const row = Buffer.alloc(stride);
      raw.copy(row, 0, p, p + stride);
      p += stride;
      for (let i = 0; i < stride; i++) {
        const a = i >= bpp ? row[i - bpp] : 0;
        const b = prev[i];
        const c = i >= bpp ? prev[i - bpp] : 0;
        let v: number;
        switch (filter) {
          case 1:
            v = row[i] + a;
            break;
          case 2:
            v = row[i] + b;
            break;
          case 3:
            v = row[i] + ((a + b) >> 1);
            break;
          case 4: {
            const q = a + b - c;
            const pa = Math.abs(q - a);
            const pb = Math.abs(q - b);
            const pc = Math.abs(q - c);
            v = row[i] + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c);
            break;
          }
          default:
            v = row[i];
        }
        row[i] = v & 0xff;
      }
      row.copy(prev);
      for (let x = 0; x < w; x++) {
        const o = x * bpp;
        let fg: boolean;
        if (hasAlpha) {
          // 4 通道透明 PNG（如阿里云分割返回）：alpha 通道即前景 mask。
          fg = row[o + bpp - 1] > 128;
        } else {
          const lum = channels === 1 ? row[o] : Math.round((row[o] + row[o + 1] + row[o + 2]) / 3);
          fg = lum > 128;
        }
        alpha[y * w + x] = fg ? 1 : 0;
      }
    }
    return { w, h, alpha };
  } catch {
    return null;
  }
}

function bboxOfMask(m: PngMask): { x: number; y: number; w: number; h: number } | null {
  let x0 = m.w;
  let y0 = m.h;
  let x1 = -1;
  let y1 = -1;
  let n = 0;
  for (let y = 0; y < m.h; y++) {
    for (let x = 0; x < m.w; x++) {
      if (m.alpha[y * m.w + x]) {
        n++;
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
    }
  }
  if (n === 0) return null;
  return { x: x0 / m.w, y: y0 / m.h, w: (x1 - x0 + 1) / m.w, h: (y1 - y0 + 1) / m.h };
}

function bboxOfMaskFile(filePath: string): { x: number; y: number; w: number; h: number } | null {
  try {
    const m = parsePngMask(fs.readFileSync(filePath));
    return m ? bboxOfMask(m) : null;
  } catch {
    return null;
  }
}

/* ---------------- 连通域分析：从合并前景中取出点击点所在的实例 ----------------
 * 阿里云 SegmentCommonImage 返回的是合并前景（多实例不区分），本地做 4 连通
 * flood fill 取点击坐标所在的连通域；点击点落在背景上时降级为最大连通域并记日志。
 */

export interface ComponentResult {
  /** 1 = 该实例，0 = 背景 */
  mask: Uint8Array;
  bbox: { x: number; y: number; w: number; h: number }; // 相对坐标
}

export function extractComponentAt(m: PngMask, relX: number, relY: number): ComponentResult | null {
  const { w, h, alpha } = m;
  const sx = Math.min(w - 1, Math.max(0, Math.round(relX * w)));
  const sy = Math.min(h - 1, Math.max(0, Math.round(relY * h)));
  const visited = new Uint8Array(w * h);
  const stack: number[] = [];

  const flood = (seedIdx: number): { pixels: number[]; } => {
    const pixels: number[] = [];
    stack.length = 0;
    stack.push(seedIdx);
    visited[seedIdx] = 1;
    while (stack.length > 0) {
      const idx = stack.pop()!;
      pixels.push(idx);
      const x = idx % w;
      const y = (idx / w) | 0;
      if (x > 0 && !visited[idx - 1] && alpha[idx - 1]) { visited[idx - 1] = 1; stack.push(idx - 1); }
      if (x < w - 1 && !visited[idx + 1] && alpha[idx + 1]) { visited[idx + 1] = 1; stack.push(idx + 1); }
      if (y > 0 && !visited[idx - w] && alpha[idx - w]) { visited[idx - w] = 1; stack.push(idx - w); }
      if (y < h - 1 && !visited[idx + w] && alpha[idx + w]) { visited[idx + w] = 1; stack.push(idx + w); }
    }
    return { pixels };
  };

  let pixels: number[];
  const seed = sy * w + sx;
  if (alpha[seed]) {
    pixels = flood(seed).pixels;
  } else {
    // 点击点落在背景上：取最大连通域并明示日志（用户点偏时的兜底）。
    console.warn('[aliyun-segment] 点击点不在任何前景区域，降级为最大连通域');
    let best: number[] = [];
    for (let i = 0; i < w * h; i++) {
      if (!visited[i] && alpha[i]) {
        const c = flood(i).pixels;
        if (c.length > best.length) best = c;
      }
    }
    if (best.length === 0) return null;
    pixels = best;
  }

  const mask = new Uint8Array(w * h);
  let x0 = w, y0 = h, x1 = -1, y1 = -1;
  for (const idx of pixels) {
    mask[idx] = 1;
    const x = idx % w;
    const y = (idx / w) | 0;
    if (x < x0) x0 = x;
    if (x > x1) x1 = x;
    if (y < y0) y0 = y;
    if (y > y1) y1 = y;
  }
  return {
    mask,
    bbox: { x: x0 / w, y: y0 / h, w: (x1 - x0 + 1) / w, h: (y1 - y0 + 1) / h },
  };
}

/* ---------------- 最小 PNG 编码器（写二值 mask，无第三方依赖） ---------------- */

const CRC_TABLE: Uint32Array = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type: string, data: Buffer): Buffer {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

/** 把二值 mask（Uint8Array，1=前景）编码为 8bit 灰度 PNG。 */
export function encodeBinaryMaskPng(w: number, h: number, mask: Uint8Array): Buffer {
  const raw = Buffer.alloc(h * (w + 1));
  for (let y = 0; y < h; y++) {
    raw[y * (w + 1)] = 0; // filter type 0（None）
    for (let x = 0; x < w; x++) raw[y * (w + 1) + 1 + x] = mask[y * w + x] ? 255 : 0;
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 0; // color type 0（灰度）
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([
    sig,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', deflateSync(raw)),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ---------------- RealSelectorAdapter：Replicate SAM（已废弃，不再推荐） ----------------
 * 保留仅为兼容：需外币支付方式的国外账号。新链路请用 AI_PROVIDER=aliyun
 *（AliyunSelectorAdapter，国内账号即可）。 */

/** @deprecated 使用 AliyunSelectorAdapter（AI_PROVIDER=aliyun）。 */
export interface Point2D {
  x: number; // 相对坐标 0-1
  y: number; // 相对坐标 0-1
}

export interface RealMaskResult {
  label: string;
  bbox: { x: number; y: number; w: number; h: number }; // 相对坐标
  maskUri: string; // '/masks/<uuid>.png'，二值 PNG
  source: 'replicate-sam' | 'aliyun-segment';
  costCny: number;
  latencyMs: number;
}

const REPLICATE_API = 'https://api.replicate.com/v1';

/** @deprecated 使用 AliyunSelectorAdapter（AI_PROVIDER=aliyun）。 */
export class RealSelectorAdapter {
  async selectObject(assetUri: string, point: Point2D, labelHint?: string): Promise<RealMaskResult> {
    const token = requireEnv('REPLICATE_API_TOKEN', '去 replicate.com/account/api-tokens 复制');
    if (!SAM_MODEL.includes('/')) throw new Error(`REPLICATE_SAM_MODEL 格式应为 owner/name，当前: ${SAM_MODEL}`);
    if (point.x < 0 || point.x > 1 || point.y < 0 || point.y > 1) {
      throw new Error(`点击坐标越界: ${JSON.stringify(point)}（应为 0-1 相对坐标）`);
    }
    const t0 = Date.now();
    const { bytes, mime } = await resolveImageBytes(assetUri);
    const size = imageSizeOf(bytes, mime);
    const px = Math.round(point.x * size.w);
    const py = Math.round(point.y * size.h);

    // [待核对]input 字段名（point_coords / point_labels）以 Replicate 模型页实时文档为准；
    // 社区 SAM 包装版本众多，字段名可能不同；另注意此处用的是像素坐标。
    const input = {
      image: toDataUri(bytes, mime),
      point_coords: [[px, py]],
      point_labels: [1], // 1 = 前景点
    };
    const [owner, name] = SAM_MODEL.split('/');
    const create = await fetchWithTimeout(
      `${REPLICATE_API}/models/${owner}/${name}/predictions`,
      {
        method: 'POST',
        // [待核对]Replicate REST 鉴权头为 "Authorization: Token <token>"（非 Bearer）。
        headers: { 'Content-Type': 'application/json', Authorization: `Token ${token}` },
        body: JSON.stringify({ input }),
      },
      30_000
    );
    if (!create.ok) {
      const body = await create.text().catch(() => '');
      throw new Error(`Replicate 创建 prediction 失败: HTTP ${create.status} ${body.slice(0, 200)}`);
    }
    const created = (await create.json()) as { id?: string; urls?: { get?: string }; error?: unknown };
    const predictionId = created.id;
    const pollUrl = created.urls?.get ?? (predictionId ? `${REPLICATE_API}/predictions/${predictionId}` : null);
    if (!predictionId || !pollUrl) throw new Error(`Replicate 返回异常: ${JSON.stringify(created).slice(0, 200)}`);

    // 轮询直到终态（SAM 通常 3–8 秒）。
    const deadline = Date.now() + 180_000;
    let output: unknown = null;
    for (;;) {
      await new Promise((r) => setTimeout(r, 2500));
      const pr = await fetchWithTimeout(pollUrl, { headers: { Authorization: `Token ${token}` } }, 30_000);
      if (!pr.ok) throw new Error(`Replicate 轮询失败: HTTP ${pr.status}`);
      const pj = (await pr.json()) as { status?: string; output?: unknown; error?: unknown };
      if (pj.status === 'succeeded') {
        output = pj.output;
        break;
      }
      if (pj.status === 'failed' || pj.status === 'canceled') {
        throw new Error(`SAM 推理失败: ${JSON.stringify(pj.error).slice(0, 300)}`);
      }
      if (Date.now() > deadline) throw new Error('SAM 推理超时（180s）');
    }

    // [待核对]社区模型输出形态不一：可能是 mask 图 URL 字符串、URL 数组，或含 mask 字段的对象。
    const maskUrl = extractFirstUrl(output);
    if (!maskUrl) throw new Error(`无法解析 SAM 输出: ${JSON.stringify(output).slice(0, 200)}`);

    const maskUri = `/masks/${crypto.randomUUID()}.png`;
    await downloadToFile(maskUrl, maskUri, 120_000);

    let bbox = bboxOfMaskFile(publicFilePath(maskUri));
    if (!bbox) {
      // 兜底：mask 解析失败时，用点击位置为中心的小框展示，并明示日志。
      console.warn(`[sam] mask PNG 解析失败(${maskUri})，bbox 降级为点击位置周边`);
      const s = 0.12;
      const bx = Math.max(0, point.x - s / 2);
      const by = Math.max(0, point.y - s / 2);
      bbox = { x: bx, y: by, w: Math.min(s, 1 - bx), h: Math.min(s, 1 - by) };
    }
    return {
      label: labelHint ?? '点选区域',
      bbox,
      maskUri,
      source: 'replicate-sam',
      costCny: COST_SAM_CNY,
      latencyMs: Date.now() - t0,
    };
  }
}

function extractFirstUrl(output: unknown): string | null {
  if (typeof output === 'string' && /^https?:\/\//i.test(output)) return output;
  if (Array.isArray(output)) {
    for (const v of output) {
      const u = extractFirstUrl(v);
      if (u) return u;
    }
    return null;
  }
  if (output && typeof output === 'object') {
    const o = output as Record<string, unknown>;
    for (const k of ['mask', 'mask_url', 'url', 'image']) {
      const u = extractFirstUrl(o[k]);
      if (u) return u;
    }
  }
  return null;
}

/** 读 JPEG/PNG 文件头尺寸。 */
function imageSizeOf(bytes: Buffer, mime: string): { w: number; h: number } {
  if (mime === 'image/png' || (bytes[0] === 0x89 && bytes[1] === 0x50)) {
    return { w: bytes.readUInt32BE(16), h: bytes.readUInt32BE(20) };
  }
  if (mime === 'image/jpeg' || (bytes[0] === 0xff && bytes[1] === 0xd8)) {
    let off = 2;
    while (off + 9 < bytes.length) {
      if (bytes[off] !== 0xff) break;
      const marker = bytes[off + 1];
      const len = bytes.readUInt16BE(off + 2);
      if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8) {
        return { h: bytes.readUInt16BE(off + 5), w: bytes.readUInt16BE(off + 7) };
      }
      off += 2 + len;
    }
  }
  throw new Error('无法解析图片尺寸（仅支持 JPEG/PNG），请换一张图');
}

/* ---------------- AliyunSelectorAdapter：阿里云视觉智能开放平台 图像分割（国内默认推荐） ----------------
 *
 * 接口：SegmentCommonImage（通用场景图像分割，家具/植物/车辆等都算通用）。
 * 文档（图像分割 cn_zh-CN PDF，含 SegmentCommonImage 通用场景语法与示例）：
 *   https://static-aliyun-doc.oss-cn-hangzhou.aliyuncs.com/download%2Fpdf%2F146441%2F%25E5%259B%25BE%25E5%2583%258F%25E5%2588%2586%25E5%2589%25B2_cn_zh-CN.pdf
 * 调用方式：RPC API，AccessKey 签名（HMAC-SHA1，SignatureVersion 1.0），无 AppCode 方式。
 *   endpoint: https://imageseg.cn-shanghai.aliyuncs.com/
 *   请求：Action=SegmentCommonImage&ImageURL=<公网图片URL>+ 公共请求参数（签名）。
 *   返回：Data.ImageURL -> 抠图结果（4 通道透明 PNG，有效期 30 分钟）。
 * 输入限制：图片 <=3M；格式 JPEG/JPG/PNG/BMP/WEBP；[待核对]通用分割分辨率上限以文档为准
 *   （商品分割为 <1280x1280）。
 *
 * 重要约束：ImageURL 必须是阿里云可公网访问的 URL。
 *   - assetUri 是 http(s) URL：直接传。
 *   - assetUri 是本地文件（/samples、/uploads）：需配置 ALIYUN_IMAGE_BASE_URL
 *     （如 OSS bucket 域名或内网穿透地址），拼成公网 URL；未配置则明确报错，不静默失败。
 *   - data: URI：无法转为公网 URL，明确报错。
 *
 * 实例区分：API 返回的是合并前景（多实例不区分）-> 本地用 alpha 通道转二值 mask，
 *   再用连通域分析取点击坐标所在的连通域（extractComponentAt），写回二值 PNG。
 */

/** 视觉智能开放平台 imageseg 产品 API 版本。[待核对]以官方文档实时口径为准。 */
export const ALIYUN_IMAGESEG_VERSION = process.env.ALIYUN_IMAGESEG_VERSION?.trim() || '2019-12-30';
export const ALIYUN_IMAGESEG_ENDPOINT = 'https://imageseg.cn-shanghai.aliyuncs.com/';

function aliyunPercentEncode(s: string): string {
  return encodeURIComponent(s)
    .replace(/!/g, '%21')
    .replace(/'/g, '%27')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29')
    .replace(/\*/g, '%2A');
}

/** 阿里云 RPC API 签名（HMAC-SHA1）。返回完整 query string（含 Signature）。 */
export function signAliyunRpc(params: Record<string, string>, accessKeySecret: string): string {
  const keys = Object.keys(params).sort();
  const canonical = keys
    .map((k) => `${aliyunPercentEncode(k)}=${aliyunPercentEncode(params[k])}`)
    .join('&');
  const stringToSign = `GET&${aliyunPercentEncode('/')}&${aliyunPercentEncode(canonical)}`;
  const signature = crypto
    .createHmac('sha1', `${accessKeySecret}&`)
    .update(stringToSign, 'utf8')
    .digest('base64');
  return `${canonical}&${aliyunPercentEncode('Signature')}=${aliyunPercentEncode(signature)}`;
}

/** 把 assetUri 解析为阿里云可拉取的公网 ImageURL。 */
export function resolvePublicImageUrl(assetUri: string): string {
  if (/^https?:\/\//i.test(assetUri)) return assetUri;
  if (assetUri.startsWith('data:')) {
    throw new Error(
      '阿里云图像分割要求 ImageURL 为公网可访问的图片地址，data: URI 无法使用；' +
        '请上传文件后配置 ALIYUN_IMAGE_BASE_URL，或直接使用 http(s) 图片地址'
    );
  }
  const base = process.env.ALIYUN_IMAGE_BASE_URL?.trim().replace(/\/+$/, '');
  if (!base) {
    throw new Error(
      `本地图片 ${assetUri} 需要公网 URL 才能调阿里云分割：请设置 ALIYUN_IMAGE_BASE_URL ` +
        '（如 OSS bucket 域名或内网穿透地址），或改用 http(s) 图片地址。自用 demo 要求诚实失败，不回退 Mock。'
    );
  }
  const rel = assetUri.startsWith('/') ? assetUri : `/${assetUri}`;
  return `${base}${rel}`;
}

export class AliyunSelectorAdapter {
  async selectObject(assetUri: string, point: Point2D, labelHint?: string): Promise<RealMaskResult> {
    const keyId = requireEnv('ALIYUN_ACCESS_KEY_ID', '去阿里云控制台-访问控制 RAM 创建 AccessKey');
    const keySecret = requireEnv('ALIYUN_ACCESS_KEY_SECRET', '与 ALIYUN_ACCESS_KEY_ID 配对的 AccessKeySecret');
    if (point.x < 0 || point.x > 1 || point.y < 0 || point.y > 1) {
      throw new Error(`点击坐标越界: ${JSON.stringify(point)}（应为 0-1 相对坐标）`);
    }
    const t0 = Date.now();
    // 本地图片先同步到 OSS（没有才上传），拿到阿里云可拉取的公网 URL。
    const imageUrl = await ensureOssPublicUrl(assetUri);

    const params: Record<string, string> = {
      Action: 'SegmentCommonImage',
      ImageURL: imageUrl,
      Format: 'JSON',
      // [待核对]Version 与 RegionId 以官方文档实时口径为准。
      Version: ALIYUN_IMAGESEG_VERSION,
      RegionId: 'cn-shanghai',
      AccessKeyId: keyId,
      SignatureMethod: 'HMAC-SHA1',
      SignatureNonce: crypto.randomUUID(),
      SignatureVersion: '1.0',
      Timestamp: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    };
    const url = `${ALIYUN_IMAGESEG_ENDPOINT}?${signAliyunRpc(params, keySecret)}`;
    const r = await fetchWithTimeout(url, { method: 'GET' }, 60_000);
    const text = await r.text();
    if (!r.ok) {
      throw new Error(`阿里云图像分割请求失败: HTTP ${r.status} ${text.slice(0, 300)}`);
    }
    let j: { Data?: { ImageURL?: string }; Code?: string; Message?: string };
    try {
      j = JSON.parse(text);
    } catch {
      throw new Error(`阿里云图像分割返回非 JSON: ${text.slice(0, 200)}`);
    }
    const resultUrl = j.Data?.ImageURL;
    if (!resultUrl) {
      throw new Error(
        `阿里云图像分割返回无结果图: ${text.slice(0, 300)}` +
          (j.Code ? `（Code=${j.Code} Message=${j.Message ?? ''}）` : '')
      );
    }

    const maskUri = `/masks/${crypto.randomUUID()}.png`;
    await downloadToFile(resultUrl, maskUri, 120_000);

    const parsed = parsePngMask(fs.readFileSync(publicFilePath(maskUri)));
    if (!parsed) {
      throw new Error(`阿里云返回的分割图 PNG 解析失败(${maskUri})，未扣除点数`);
    }
    const comp = extractComponentAt(parsed, point.x, point.y);
    if (!comp) {
      throw new Error('阿里云分割返回的前景为空，无法选区，未扣除点数');
    }
    // 写回二值 mask（与 Replicate 链路契约一致：maskUri 指向二值 PNG）。
    fs.writeFileSync(publicFilePath(maskUri), encodeBinaryMaskPng(parsed.w, parsed.h, comp.mask));

    return {
      label: labelHint ?? '点选区域',
      bbox: comp.bbox,
      maskUri,
      source: 'aliyun-segment',
      costCny: COST_ALIYUN_SEGMENT_CNY,
      latencyMs: Date.now() - t0,
    };
  }
}

/* ---------------- RealEditAdapter：Seedream（主）/ Gemini（备） ---------------- */

export interface RealEditRequest {
  imageUri: string; // 原图：'/samples/a.jpg' | '/uploads/x.jpg' | http(s) URL
  maskUri: string | null; // '/masks/<uuid>.png'；null = 纯提示词
  prompt: string; // 用户中文指令
  label?: string; // 选中对象名称，用于拼提示词
  outputId?: string; // 结果文件名（默认 uuid）
}

export interface RealEditResult {
  resultUri: string; // '/edits/<id>.jpg'
  modelVersion: string;
  simulated: false;
  costCny: number;
  latencyMs: number;
  maskSent: boolean; // mask 是否实际发出
}

/** 把用户口语指令包装成“只改选中对象”的改图提示词。 */
function buildEditPrompt(prompt: string, label?: string, withMask?: boolean): string {
  const target = label && label !== '点选区域' ? `「${label}」` : '被选中的对象';
  const maskNote = withMask ? `图中附带的遮罩标出了${target}的位置，` : '';
  return (
    `请对这张室内照片做局部修改：${prompt}。` +
    `要求：${maskNote}只修改${target}，其余区域（墙面、其他家具、光影、构图）保持原样；` +
    `修改效果自然真实，与原图的光线和风格一致；不要添加水印和文字。`
  );
}

function maskLooksUnsupported(status: number, bodyText: string): boolean {
  return status === 400 && /mask|unknown field|invalid_request|unrecognized/i.test(bodyText);
}

export class SeedreamEditAdapter {
  async edit(req: RealEditRequest): Promise<RealEditResult> {
    const apiKey = requireEnv('ARK_API_KEY', '去火山引擎控制台-火山方舟创建 API key');
    const maskMode = readMaskMode();
    const t0 = Date.now();
    const { bytes, mime } = await resolveImageBytes(req.imageUri);
    const fullPrompt = buildEditPrompt(req.prompt, req.label, !!req.maskUri);

    const payload: Record<string, unknown> = {
      model: SEEDREAM_MODEL,
      prompt: fullPrompt,
      image: toDataUri(bytes, mime),
    };

    let maskSent = false;
    if (maskMode === 'auto' && req.maskUri) {
      try {
        const maskBytes = fs.readFileSync(publicFilePath(req.maskUri));
        // [待核对]"mask" 为探针假设字段：Seedream 公开文档走“参考图+提示词”路线，
        // 原生 mask 通道是否存在必须用真 key 验证；验证它正是探针目的之一。
        payload['mask'] = toDataUri(maskBytes, 'image/png');
        maskSent = true;
      } catch (e) {
        console.warn(`[seedream] mask 文件读取失败(${(e as Error).message})，降级为纯提示词模式`);
      }
    } else if (req.maskUri) {
      console.log('[seedream] AI_MASK_MODE=off，mask 不发送，走纯提示词模式');
    }

    const endpoint = `${ARK_BASE_URL}/api/v3/images/generations`;
    const doCall = async (withMask: boolean): Promise<string> => {
      const body: Record<string, unknown> = {
        model: payload['model'],
        prompt: payload['prompt'],
        image: payload['image'],
      };
      if (withMask && maskSent) body['mask'] = payload['mask'];
      const r = await fetchWithTimeout(
        endpoint,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
          body: JSON.stringify(body),
        },
        300_000
      );
      const text = await r.text();
      if (!r.ok) {
        const err = new Error(`Seedream 请求失败: HTTP ${r.status} ${text.slice(0, 300)}`) as Error & {
          status?: number;
          bodyText?: string;
        };
        err.status = r.status;
        err.bodyText = text;
        throw err;
      }
      let j: { data?: Array<{ url?: string }> };
      try {
        j = JSON.parse(text);
      } catch {
        throw new Error(`Seedream 返回非 JSON: ${text.slice(0, 200)}`);
      }
      // [待核对]返回口径 data[0].url 以火山方舟官方文档为准。
      const url = j.data?.[0]?.url;
      if (!url) throw new Error(`Seedream 返回无图片 URL: ${text.slice(0, 300)}`);
      return url;
    };

    let imageUrl: string;
    try {
      imageUrl = await doCall(maskSent);
    } catch (e) {
      const err = e as Error & { status?: number; bodyText?: string };
      if (maskSent && err.status !== undefined && maskLooksUnsupported(err.status, err.bodyText ?? '')) {
        // mask 字段被拒绝：明示日志，降级重试（只多花一次纯提示词的费用）。
        console.warn(
          '[seedream] mask 字段被 API 拒绝（疑似不支持原生 mask），已降级为纯提示词模式重试。' +
            '这是选型最大不确定项，详见预研报告 phase1-tech-research.md §2。'
        );
        maskSent = false;
        imageUrl = await doCall(false);
      } else {
        throw e;
      }
    }

    const outId = req.outputId ?? crypto.randomUUID();
    const resultUri = `/edits/${outId}.jpg`;
    await downloadToFile(imageUrl, resultUri, 300_000);
    return {
      resultUri,
      modelVersion: SEEDREAM_MODEL,
      simulated: false,
      costCny: COST_SEEDREAM_CNY,
      latencyMs: Date.now() - t0,
      maskSent,
    };
  }
}

export class GeminiEditAdapter {
  async edit(req: RealEditRequest): Promise<RealEditResult> {
    const apiKey = requireEnv('GEMINI_API_KEY', '去 Google AI Studio 创建 API key');
    const t0 = Date.now();
    const { bytes, mime } = await resolveImageBytes(req.imageUri);
    const fullPrompt = buildEditPrompt(req.prompt, req.label);
    if (req.maskUri) {
      // Gemini 无原生 mask 通道，靠自然语言定位；mask 仅记日志，不发送。
      console.log('[gemini] 无原生 mask 通道，mask 不发送，靠提示词定位修改对象');
    }
    const url =
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}` +
      `:generateContent?key=${encodeURIComponent(apiKey)}`;
    // [待核对]请求体/返回口径以 AI Studio 实时文档为准：
    // generationConfig.responseModalities 需含 "IMAGE"；返回 candidates[0].content.parts[].inlineData。
    const r = await fetchWithTimeout(
      url,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { inline_data: { mime_type: mime, data: bytes.toString('base64') } },
                { text: fullPrompt },
              ],
            },
          ],
          generationConfig: { responseModalities: ['TEXT', 'IMAGE'] },
        }),
      },
      300_000
    );
    const text = await r.text();
    if (!r.ok) throw new Error(`Gemini 请求失败: HTTP ${r.status} ${text.slice(0, 300)}`);
    let j: {
      candidates?: Array<{ content?: { parts?: Array<{ inlineData?: { data?: string; mimeType?: string } }> } }>;
    };
    try {
      j = JSON.parse(text);
    } catch {
      throw new Error(`Gemini 返回非 JSON: ${text.slice(0, 200)}`);
    }
    const parts = j.candidates?.[0]?.content?.parts ?? [];
    const imgPart = parts.find((p) => p.inlineData?.data);
    if (!imgPart?.inlineData?.data) throw new Error(`Gemini 返回无图片: ${text.slice(0, 300)}`);

    const outId = req.outputId ?? crypto.randomUUID();
    const ext = (imgPart.inlineData.mimeType ?? 'image/png').includes('jpeg') ? 'jpg' : 'png';
    const resultUri = `/edits/${outId}.${ext}`;
    const dest = publicFilePath(resultUri);
    ensureDir(path.dirname(dest));
    fs.writeFileSync(dest, Buffer.from(imgPart.inlineData.data, 'base64'));
    return {
      resultUri,
      modelVersion: GEMINI_MODEL,
      simulated: false,
      costCny: COST_GEMINI_CNY,
      latencyMs: Date.now() - t0,
      maskSent: false,
    };
  }
}

/* ---------------- 工厂：按 AI_PROVIDER 取适配器；key 缺失时抛错，不回退 Mock ----------------
 * - AI_PROVIDER=aliyun（国内默认推荐）：阿里云图像分割点选 + 火山即梦改图（全国内链路）。
 * - AI_PROVIDER=seedream|gemini：Replicate SAM 点选（已废弃）+ 对应改图。
 */

export function getRealSelectorAdapter(): RealSelectorAdapter | AliyunSelectorAdapter {
  if (readProvider() === 'aliyun') return new AliyunSelectorAdapter();
  return new RealSelectorAdapter(); // 已废弃，仅兼容
}

export function getRealEditAdapter(): SeedreamEditAdapter | GeminiEditAdapter {
  const provider = readProvider();
  // aliyun = 国内全链路：改图仍走火山即梦（已是国内）。
  if (provider === 'seedream' || provider === 'aliyun') return new SeedreamEditAdapter();
  if (provider === 'gemini') return new GeminiEditAdapter();
  throw new Error(
    `AI_PROVIDER=${process.env.AI_PROVIDER ?? '(未设置)'} 为 mock，真实改图适配器不可用。` +
      `如需真实改图，请设置 AI_PROVIDER=seedream|gemini|aliyun 并配置对应 key。`
  );
}

/** 真实改图链路的 model_version（写入 edit_job.model_version）。 */
export function realModelVersion(): string {
  const provider = readProvider();
  if (provider === 'seedream' || provider === 'aliyun') return SEEDREAM_MODEL;
  if (provider === 'gemini') return GEMINI_MODEL;
  return 'mock-edit-v1';
}
