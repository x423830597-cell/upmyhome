import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

const DB_PATH = path.join(process.cwd(), 'data', 'prototype.db');

let db: DatabaseSync | null = null;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS project (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  title TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS asset (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  uri TEXT NOT NULL,
  width INTEGER,
  height INTEGER,
  hash TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS selection (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL,
  mask_asset_id TEXT,
  label TEXT NOT NULL,
  bbox TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS edit_job (
  id TEXT PRIMARY KEY,
  selection_id TEXT NOT NULL,
  prompt TEXT NOT NULL,
  prompt_type TEXT NOT NULL,
  prompt_length INTEGER NOT NULL,
  status TEXT NOT NULL,
  model_version TEXT NOT NULL,
  points_cost INTEGER NOT NULL,
  actual_ai_cost REAL NOT NULL,
  latency_ms INTEGER,
  error_class TEXT,
  result_uri TEXT,
  idem_key TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS point_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  delta INTEGER NOT NULL,
  reason TEXT NOT NULL,
  job_id TEXT,
  idem_key TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ledger_session ON point_ledger(session_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ledger_idem ON point_ledger(idem_key);
CREATE TABLE IF NOT EXISTS event (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  session_id TEXT NOT NULL,
  project_id TEXT,
  job_id TEXT,
  ts TEXT NOT NULL,
  props TEXT
);
CREATE INDEX IF NOT EXISTS idx_event_session ON event(session_id);
`;

export function newId(): string {
  return crypto.randomUUID();
}

export function nowIso(): string {
  return new Date().toISOString();
}

function recoverStaleJobs(database: DatabaseSync) {
  // Phase 0 单进程 worker：重启后把未终态任务标记失败并退点，保证账本一致。
  // session_id 经 selection → asset → project 关联取得（edit_job 本身不存 session_id）。
  const stale = database
    .prepare(
      `SELECT j.id AS id, j.points_cost AS points_cost, j.idem_key AS idem_key, p.session_id AS session_id
       FROM edit_job j
       JOIN selection s ON s.id = j.selection_id
       JOIN asset a ON a.id = s.asset_id
       JOIN project p ON p.id = a.project_id
       WHERE j.status IN ('created','charged','processing')`
    )
    .all() as { id: string; session_id: string; points_cost: number; idem_key: string }[];
  for (const job of stale) {
    const ts = nowIso();
    database.prepare(`UPDATE edit_job SET status='failed', error_class='server_restart', updated_at=? WHERE id=?`).run(ts, job.id);
    database.prepare(
      `INSERT OR IGNORE INTO point_ledger (session_id, delta, reason, job_id, idem_key, created_at) VALUES (?,?,?,?,?,?)`
    ).run(job.session_id, job.points_cost, 'refund', job.id, `refund:${job.id}`, ts);
    database.prepare(`UPDATE edit_job SET status='refunded', updated_at=? WHERE id=?`).run(ts, job.id);
    database.prepare(
      `INSERT INTO event (name, session_id, project_id, job_id, ts, props) VALUES (?,?,?,?,?,?)`
    ).run('edit_failed', job.session_id, null, job.id, ts, JSON.stringify({ error_class: 'server_restart', refunded: true }));
  }
}

export function getDb(): DatabaseSync {
  if (db) return db;
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec(SCHEMA);
  recoverStaleJobs(db);
  return db;
}
