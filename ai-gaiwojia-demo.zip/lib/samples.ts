// 样板房定义：MockMask 的精选热点（Phase 1 替换为 SAM 时保持同一接口）。
// bbox 为相对坐标 {x, y, w, h}，取值 0~1。

export interface QuickInstruction {
  id: string;
  text: string;
  keywords: string[]; // 自由文本指令做关键词匹配用
  resultImage: string; // 预生成的模拟结果图
}

export interface Hotspot {
  id: string;
  label: string;
  bbox: { x: number; y: number; w: number; h: number };
  instructions: QuickInstruction[];
}

export interface Sample {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  hotspots: Hotspot[];
}

export const SAMPLES: Sample[] = [
  {
    id: 'room-a',
    title: '奶油风客厅',
    subtitle: '浅色系 · 采光好',
    image: '/samples/room-a.jpg',
    hotspots: [
      {
        id: 'room-a-sofa',
        label: '沙发',
        bbox: { x: 0.2, y: 0.58, w: 0.6, h: 0.26 },
        instructions: [
          {
            id: 'room-a-sofa-1',
            text: '换成浅色布艺沙发',
            keywords: ['浅色', '布艺', '米色', '亚麻'],
            resultImage: '/samples/room-a-sofa-1.jpg',
          },
          {
            id: 'room-a-sofa-2',
            text: '换成深灰色皮质沙发',
            keywords: ['深灰', '皮质', '皮', '深色'],
            resultImage: '/samples/room-a-sofa-2.jpg',
          },
        ],
      },
      {
        id: 'room-a-tvcabinet',
        label: '电视柜',
        bbox: { x: 0.76, y: 0.62, w: 0.24, h: 0.32 },
        instructions: [
          {
            id: 'room-a-tvcabinet-1',
            text: '换成悬浮原木电视柜',
            keywords: ['悬浮', '原木', '木'],
            resultImage: '/samples/room-a-tvcabinet-1.jpg',
          },
          {
            id: 'room-a-tvcabinet-2',
            text: '换成白色哑光电视柜',
            keywords: ['白色', '哑光', '白'],
            resultImage: '/samples/room-a-tvcabinet-2.jpg',
          },
        ],
      },
    ],
  },
  {
    id: 'room-b',
    title: '原木风客厅',
    subtitle: '侘寂风 · 木质感',
    image: '/samples/room-b.jpg',
    hotspots: [
      {
        id: 'room-b-table',
        label: '茶几',
        bbox: { x: 0.4, y: 0.68, w: 0.29, h: 0.24 },
        instructions: [
          {
            id: 'room-b-table-1',
            text: '换成圆形藤编茶几',
            keywords: ['藤编', '圆形', '藤'],
            resultImage: '/samples/room-b-table-1.jpg',
          },
          {
            id: 'room-b-table-2',
            text: '换成黑色大理石茶几',
            keywords: ['大理石', '黑色', '黑'],
            resultImage: '/samples/room-b-table-2.jpg',
          },
        ],
      },
      {
        id: 'room-b-curtain',
        label: '窗帘',
        bbox: { x: 0.27, y: 0.05, w: 0.6, h: 0.66 },
        instructions: [
          {
            id: 'room-b-curtain-1',
            text: '换成纱质白色窗帘',
            keywords: ['纱', '白色', '白', '薄'],
            resultImage: '/samples/room-b-curtain-1.jpg',
          },
          {
            id: 'room-b-curtain-2',
            text: '换成亚麻灰色窗帘',
            keywords: ['亚麻', '灰色', '灰'],
            resultImage: '/samples/room-b-curtain-2.jpg',
          },
        ],
      },
    ],
  },
  {
    id: 'room-c',
    title: '现代简约客厅',
    subtitle: '极简 · 大地色',
    image: '/samples/room-c.jpg',
    hotspots: [
      {
        id: 'room-c-rug',
        label: '地毯',
        bbox: { x: 0.1, y: 0.66, w: 0.8, h: 0.26 },
        instructions: [
          {
            id: 'room-c-rug-1',
            text: '换成米色羊毛地毯',
            keywords: ['羊毛', '米色', '奶油'],
            resultImage: '/samples/room-c-rug-1.jpg',
          },
          {
            id: 'room-c-rug-2',
            text: '换成几何图案地毯',
            keywords: ['几何', '图案', '花纹'],
            resultImage: '/samples/room-c-rug-2.jpg',
          },
        ],
      },
      {
        id: 'room-c-lamp',
        label: '落地灯',
        bbox: { x: 0.63, y: 0.16, w: 0.29, h: 0.6 },
        instructions: [
          {
            id: 'room-c-lamp-1',
            text: '换成白色拱形落地灯',
            keywords: ['白色', '拱形', '白'],
            resultImage: '/samples/room-c-lamp-1.jpg',
          },
          {
            id: 'room-c-lamp-2',
            text: '换成极简黑色落地灯',
            keywords: ['黑色', '极简', '黑', '直'],
            resultImage: '/samples/room-c-lamp-2.jpg',
          },
        ],
      },
    ],
  },
  {
    id: 'room-d',
    title: '轻奢风客厅',
    subtitle: '复古 · 质感',
    image: '/samples/room-d.jpg',
    hotspots: [
      {
        id: 'room-d-chair',
        label: '单人椅',
        bbox: { x: 0.01, y: 0.52, w: 0.28, h: 0.46 },
        instructions: [
          {
            id: 'room-d-chair-1',
            text: '换成焦糖色皮质单人椅',
            keywords: ['焦糖', '皮质', '皮'],
            resultImage: '/samples/room-d-chair-1.jpg',
          },
          {
            id: 'room-d-chair-2',
            text: '换成墨绿色绒布单人椅',
            keywords: ['墨绿', '绒布', '绿'],
            resultImage: '/samples/room-d-chair-2.jpg',
          },
        ],
      },
      {
        id: 'room-d-art',
        label: '挂画',
        bbox: { x: 0.37, y: 0.16, w: 0.2, h: 0.36 },
        instructions: [
          {
            id: 'room-d-art-1',
            text: '换成抽象线条挂画',
            keywords: ['线条', '抽象', '简约'],
            resultImage: '/samples/room-d-art-1.jpg',
          },
          {
            id: 'room-d-art-2',
            text: '换成黑白摄影挂画',
            keywords: ['摄影', '黑白', '照片'],
            resultImage: '/samples/room-d-art-2.jpg',
          },
        ],
      },
    ],
  },
];

export function findHotspot(hotspotId: string): { sample: Sample; hotspot: Hotspot } | null {
  for (const sample of SAMPLES) {
    const hotspot = sample.hotspots.find((h) => h.id === hotspotId);
    if (hotspot) return { sample, hotspot };
  }
  return null;
}

/** 自由文本指令 → 关键词匹配最接近的快捷指令结果图；兜底取第一个。 */
export function matchInstruction(hotspot: Hotspot, text: string): QuickInstruction {
  let best = hotspot.instructions[0];
  let bestScore = 0;
  for (const inst of hotspot.instructions) {
    const score = inst.keywords.filter((k) => text.includes(k)).length;
    if (score > bestScore) {
      bestScore = score;
      best = inst;
    }
  }
  return best;
}
