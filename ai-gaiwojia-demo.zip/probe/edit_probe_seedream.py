#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
「AI改我家」Phase 1 探针 - 火山引擎 Seedream 改图探针（主链路）。

流程：
  1. 从 probe_cases.build_edit_cases() 取 24 组样例（16 快捷指令 + 8 自由中文指令）。
  2. 默认 24 组走「参考图 + 提示词」路线（Seedream 的公开 i2i 口径），不传 mask。
  3. --mask-ab（默认开启）：每热点取第 1 条快捷指令样例，额外跑 1 组传 mask 版
     （case_id 为 E01-mask 形式），用于验证 Seedream 原生 mask 是否生效。
     判定方式：人工评分时对比同一指令有/无 mask 的 ① 分（未选区域结构保持）。
  4. 结果图存 results/seedream/<case_id>.jpg，元数据记入 manifest.json。

环境变量：
  ARK_API_KEY      必填，火山方舟 API key（从环境变量读，绝不写死）。
  SEEDREAM_MODEL   可选，默认为 "seedream-5-0"；请以火山方舟控制台实际模型 ID 为准。

API：POST https://ark.cn-beijing.volcengine.com/api/v3/images/generations
     Header: Authorization: Bearer $ARK_API_KEY
     字段口径以火山方舟官方文档为准；mask 字段为探针假设字段——
     本探针的核心目的之一就是验证它是否被接受/生效：
     若 API 直接报错，说明不支持；若接受但结果 ① 分无差异，说明未生效。

费用：Seedream 5.0 公开价 ¥0.22/张（2026-09-23 查询）。
  24 组 ≈ ¥5.28；+8 组 mask A/B ≈ ¥7.04，均在 <¥10 探针预算内。

本脚本需要网络与有效 key；无 key 时请勿运行（只做 py_compile 语法检查）。
"""

import argparse
import base64
import json
import os
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from probe_cases import (PROTOTYPE_DIR, build_edit_cases, mask_ab_cases)  # noqa: E402

try:
    from PIL import Image
except ImportError:
    sys.exit("缺少 Pillow：pip install Pillow")

ARK_ENDPOINT = "https://ark.cn-beijing.volcengine.com/api/v3/images/generations"
SEEDREAM_MODEL = os.environ.get("SEEDREAM_MODEL", "seedream-5-0")
COST_CNY_PER_IMAGE = 0.22

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "seedream")
SAM_MASK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "sam")


def b64_data_uri(path, mime="image/jpeg"):
    with open(path, "rb") as f:
        return f"data:{mime};base64," + base64.b64encode(f.read()).decode()


def mask_data_uri_for(hotspot_id, src_size):
    """取 sam_probe 产出的 mask，转为与原图同尺寸的 PNG base64。

    返回 None 表示 mask 文件不存在（需先跑 sam_probe.py）。
    """
    p = os.path.join(SAM_MASK_DIR, f"{hotspot_id}_mask.png")
    if not os.path.exists(p):
        return None
    im = Image.open(p).convert("L")
    if im.size != src_size:
        im = im.resize(src_size, Image.NEAREST)
    tmp = p + ".resized_tmp.png"
    im.save(tmp)
    try:
        return b64_data_uri(tmp, "image/png")
    finally:
        os.remove(tmp)


def call_seedream(api_key, prompt, image_path, mask_b64=None):
    """调 Ark images/generations，返回 (image_url, latency_s)。"""
    body = {
        "model": SEEDREAM_MODEL,
        "prompt": prompt,
        "image": b64_data_uri(image_path),
    }
    if mask_b64 is not None:
        # 探针假设字段：验证 Seedream 是否原生支持 mask 通道
        body["mask"] = mask_b64
    req = urllib.request.Request(
        ARK_ENDPOINT,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            resp = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        raise RuntimeError(f"Ark 请求失败: {type(e).__name__}: {e}")
    latency = time.time() - t0
    try:
        url = resp["data"][0]["url"]
    except (KeyError, IndexError, TypeError):
        raise RuntimeError(f"无法解析 Ark 返回: {str(resp)[:300]}")
    return url, latency


def download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": "ai-home-probe/1.0"})
    with urllib.request.urlopen(req, timeout=300) as r, open(dest, "wb") as f:
        f.write(r.read())


def run_case(api_key, case, mask_b64, out_name):
    img_path = os.path.join(PROTOTYPE_DIR, case["image"])
    url, latency = call_seedream(api_key, case["prompt"], img_path, mask_b64)
    dest = os.path.join(OUT_DIR, out_name)
    download(url, dest)
    return {
        "case_id": case["case_id"],
        "output_id": out_name.replace(".jpg", ""),
        "sample_id": case["sample_id"],
        "hotspot_id": case["hotspot_id"],
        "label": case["label"],
        "kind": case["kind"],
        "instruction": case["instruction"],
        "mask_sent": mask_b64 is not None,
        "status": "ok",
        "error": "",
        "latency_s": round(latency, 2),
        "output_path": os.path.relpath(dest, OUT_DIR),
        "est_cost_cny": COST_CNY_PER_IMAGE,
    }


def main():
    ap = argparse.ArgumentParser(description="Seedream 改图探针")
    ap.add_argument("--no-mask-ab", action="store_true",
                    help="关闭 mask A/B 对照（默认开启：每热点 1 组传 mask 版）")
    ap.add_argument("--delay", type=float, default=2.0, help="组间等待秒数")
    args = ap.parse_args()

    api_key = os.environ.get("ARK_API_KEY")
    if not api_key:
        sys.exit("未设置 ARK_API_KEY，拒绝运行（key 只从环境变量读）。")
    os.makedirs(OUT_DIR, exist_ok=True)

    manifest = []
    cases = build_edit_cases()

    print(f"== 24 组主样例（参考图+提示词，不传 mask） model={SEEDREAM_MODEL} ==")
    for c in cases:
        t0 = time.time()
        try:
            rec = run_case(api_key, c, None, f"{c['case_id']}.jpg")
        except Exception as e:  # noqa: BLE001 - 探针要记录失败而非中断
            rec = {"case_id": c["case_id"], "output_id": c["case_id"],
                   "sample_id": c["sample_id"], "hotspot_id": c["hotspot_id"],
                   "label": c["label"], "kind": c["kind"],
                   "instruction": c["instruction"], "mask_sent": False,
                   "status": "error", "error": str(e)[:300],
                   "latency_s": round(time.time() - t0, 2),
                   "output_path": "", "est_cost_cny": 0.0}
        manifest.append(rec)
        print(f"{c['case_id']} {c['hotspot_id']} {c['instruction'][:14]}… "
              f"status={rec['status']} {rec['latency_s']}s {rec['error'][:60]}")
        time.sleep(args.delay)

    if not args.no_mask_ab:
        print("\n== 8 组 mask A/B（传 mask 版，对照组为上方同名无 mask 版） ==")
        for c in mask_ab_cases():
            img_path = os.path.join(PROTOTYPE_DIR, c["image"])
            with Image.open(img_path) as im:
                src_size = im.size
            mask_b64 = mask_data_uri_for(c["hotspot_id"], src_size)
            out_id = f"{c['case_id']}-mask"
            t0 = time.time()
            if mask_b64 is None:
                rec = {"case_id": c["case_id"], "output_id": out_id,
                       "sample_id": c["sample_id"], "hotspot_id": c["hotspot_id"],
                       "label": c["label"], "kind": c["kind"],
                       "instruction": c["instruction"], "mask_sent": True,
                       "status": "skip",
                       "error": "缺少 results/sam/<hotspot>_mask.png，请先跑 sam_probe.py",
                       "latency_s": 0.0, "output_path": "", "est_cost_cny": 0.0}
            else:
                try:
                    rec = run_case(api_key, {**c, "case_id": c["case_id"]},
                                   mask_b64, f"{out_id}.jpg")
                    rec["output_id"] = out_id
                except Exception as e:  # noqa: BLE001
                    rec = {"case_id": c["case_id"], "output_id": out_id,
                           "sample_id": c["sample_id"], "hotspot_id": c["hotspot_id"],
                           "label": c["label"], "kind": c["kind"],
                           "instruction": c["instruction"], "mask_sent": True,
                           "status": "error", "error": str(e)[:300],
                           "latency_s": round(time.time() - t0, 2),
                           "output_path": "", "est_cost_cny": 0.0}
            manifest.append(rec)
            print(f"{out_id} status={rec['status']} {rec['latency_s']}s {rec['error'][:80]}")
            time.sleep(args.delay)

    ok = [m for m in manifest if m["status"] == "ok"]
    total = sum(m["est_cost_cny"] for m in manifest)
    mp = os.path.join(OUT_DIR, "manifest.json")
    with open(mp, "w", encoding="utf-8") as f:
        json.dump({
            "provider": "seedream",
            "model": SEEDREAM_MODEL,
            "endpoint": ARK_ENDPOINT,
            "n_cases": len(manifest),
            "n_ok": len(ok),
            "mean_latency_s": round(sum(m["latency_s"] for m in ok) / len(ok), 2) if ok else 0,
            "est_total_cost_cny": round(total, 2),
            "cases": manifest,
        }, f, ensure_ascii=False, indent=2)
    print(f"\n完成：成功 {len(ok)}/{len(manifest)}，预估 ¥{total:.2f}，manifest: {mp}")
    print("下一步：按 score.csv 对 results/seedream/ 逐张人工评分（见 README 判定标准）。")


if __name__ == "__main__":
    main()
