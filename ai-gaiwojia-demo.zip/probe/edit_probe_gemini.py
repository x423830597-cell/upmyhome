#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
「AI改我家」Phase 1 探针 - Gemini 改图探针（备链路，免费额度内）。

流程：
  1. 从 probe_cases.build_edit_cases() 取同样的 24 组样例（与 Seedream 主链路
     用同一套 prompt，保证对比公平）。
  2. 调 Gemini generateContent（inline_data 传原图 + 中文提示词），解析返回的
     inlineData 图片，存到 results/gemini/<case_id>.png。
  3. 元数据记入 manifest.json。

说明：
  - Gemini 无原生 mask 通道，靠自然语言指令定位修改对象；因此不做 mask A/B，
    只验证「参考图 + 中文提示词」路线的效果，作为 Seedream 不达标时的备选。
  - 免费额度 500 次/天（全 key 共用），24 组在额度内，费用 ¥0。

环境变量：
  GEMINI_API_KEY  必填，Google AI Studio API key（从环境变量读，绝不写死）。
  GEMINI_MODEL    可选，默认 "gemini-2.5-flash-image"（二代）；
                  一代 2026-10-02 退役，若模型名变更以 AI Studio 文档为准。

API：POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key=...
     图片输出需 generationConfig.responseModalities 含 "IMAGE"，
     具体字段以 AI Studio 实时文档为准，首次运行前请核对 parse_parts()。

本脚本需要网络与有效 key；无 key 时请勿运行（只做 py_compile 语法检查）。
"""

import argparse
import base64
import json
import os
import sys
import time
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from probe_cases import PROTOTYPE_DIR, build_edit_cases  # noqa: E402

GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash-image")
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "gemini")


def call_gemini(api_key, prompt, image_path):
    """调 generateContent，返回 (png_bytes, mime_type, latency_s)。"""
    with open(image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode()
    body = {
        "contents": [{
            "parts": [
                {"inline_data": {"mime_type": "image/jpeg", "data": img_b64}},
                {"text": prompt},
            ]
        }],
        # 图片输出口径：以 AI Studio 实时文档为准
        "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]},
    }
    url = ("https://generativelanguage.googleapis.com/v1beta/models/"
           f"{urllib.parse.quote(GEMINI_MODEL, safe='')}:generateContent"
           f"?key={urllib.parse.quote(api_key, safe='')}")
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            resp = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        raise RuntimeError(f"Gemini 请求失败: {type(e).__name__}: {e}")
    latency = time.time() - t0
    return parse_image(resp, latency)


def parse_image(resp, latency):
    """从 generateContent 返回中提取 inlineData 图片。"""
    try:
        parts = resp["candidates"][0]["content"]["parts"]
    except (KeyError, IndexError, TypeError):
        raise RuntimeError(f"无法解析 Gemini 返回: {str(resp)[:300]}")
    for p in parts:
        inline = p.get("inlineData") or p.get("inline_data")
        if inline and inline.get("data"):
            mime = inline.get("mimeType", inline.get("mime_type", "image/png"))
            return base64.b64decode(inline["data"]), mime, latency
    raise RuntimeError(f"返回中没有图片数据: {str(resp)[:300]}")


def ext_for(mime):
    return {"image/png": ".png", "image/jpeg": ".jpg"}.get(mime, ".png")


def main():
    ap = argparse.ArgumentParser(description="Gemini 改图探针（免费额度）")
    ap.add_argument("--delay", type=float, default=3.0,
                    help="组间等待秒数（免费档限流，默认 3s）")
    args = ap.parse_args()

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        sys.exit("未设置 GEMINI_API_KEY，拒绝运行（key 只从环境变量读）。")
    os.makedirs(OUT_DIR, exist_ok=True)

    manifest = []
    for c in build_edit_cases():
        img_path = os.path.join(PROTOTYPE_DIR, c["image"])
        t0 = time.time()
        try:
            data, mime, latency = call_gemini(api_key, c["prompt"], img_path)
            dest = os.path.join(OUT_DIR, f"{c['case_id']}{ext_for(mime)}")
            with open(dest, "wb") as f:
                f.write(data)
            rec = {
                "case_id": c["case_id"],
                "sample_id": c["sample_id"],
                "hotspot_id": c["hotspot_id"],
                "label": c["label"],
                "kind": c["kind"],
                "instruction": c["instruction"],
                "status": "ok", "error": "",
                "latency_s": round(latency, 2),
                "output_path": os.path.relpath(dest, OUT_DIR),
                "mime_type": mime,
                "est_cost_cny": 0.0,
            }
        except Exception as e:  # noqa: BLE001 - 探针要记录失败而非中断
            rec = {
                "case_id": c["case_id"],
                "sample_id": c["sample_id"], "hotspot_id": c["hotspot_id"],
                "label": c["label"], "kind": c["kind"],
                "instruction": c["instruction"],
                "status": "error", "error": str(e)[:300],
                "latency_s": round(time.time() - t0, 2),
                "output_path": "", "mime_type": "",
                "est_cost_cny": 0.0,
            }
        manifest.append(rec)
        print(f"{c['case_id']} {c['hotspot_id']} {c['instruction'][:14]}… "
              f"status={rec['status']} {rec['latency_s']}s {rec['error'][:60]}")
        time.sleep(args.delay)

    ok = [m for m in manifest if m["status"] == "ok"]
    mp = os.path.join(OUT_DIR, "manifest.json")
    with open(mp, "w", encoding="utf-8") as f:
        json.dump({
            "provider": "gemini",
            "model": GEMINI_MODEL,
            "n_cases": len(manifest),
            "n_ok": len(ok),
            "mean_latency_s": round(sum(m["latency_s"] for m in ok) / len(ok), 2) if ok else 0,
            "est_total_cost_cny": 0.0,
            "note": "免费额度内（500 次/天，全 key 共用）",
            "cases": manifest,
        }, f, ensure_ascii=False, indent=2)
    print(f"\n完成：成功 {len(ok)}/{len(manifest)}，费用 ¥0，manifest: {mp}")
    print("下一步：按 score.csv 对 results/gemini/ 逐张人工评分（见 README 判定标准）。")


if __name__ == "__main__":
    main()
