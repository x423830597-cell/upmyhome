#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
「AI改我家」Phase 1 探针 - SAM 点选分割探针。

流程（8 个热点）：
  1. 从 probe_cases.parse_samples_ts() 读 8 个热点定义（bbox 为相对坐标）。
  2. bbox → 中心点（相对坐标 → 像素坐标），调 Replicate SAM 做点选分割。
  3. 下载返回的 mask 图，存到 results/sam/<hotspot_id>_mask.png。
  4. 由 mask 反推 bbox（相对坐标），与 samples.ts 预置 bbox 算 IoU。
  5. 记录每步延迟，输出 results/sam/sam_results.json。

环境变量：
  REPLICATE_API_TOKEN  必填，Replicate API token（从环境变量读，绝不写死）。
  REPLICATE_SAM_MODEL  可选，默认 cbx1/sam-vit-h（社区 SAM，按次计费）。

依赖：pip install replicate Pillow

注意：cbx1/sam-vit-h 的 input schema 以 Replicate 模型页实时文档为准，
首次运行前请核对 build_sam_input() 的字段名；若模型下线/改版，
换 REPLICATE_SAM_MODEL 指向同类模型即可（Adapter 隔离思想同样适用于探针）。

本脚本需要网络与有效 token；无 key 时请勿运行（只做 py_compile 语法检查）。
"""

import json
import os
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from probe_cases import (PROTOTYPE_DIR, hotspot_center, parse_samples_ts)

try:
    from PIL import Image
except ImportError:
    sys.exit("缺少 Pillow：pip install Pillow")

try:
    import replicate
except ImportError:
    sys.exit("缺少 replicate：pip install replicate")

SAM_MODEL = os.environ.get("REPLICATE_SAM_MODEL", "cbx1/sam-vit-h")
# 报告中的公开价：cbx1/sam-vit-h 约 $0.0016/次（2026-09-23 查询，实际以模型页为准）
COST_USD_PER_CALL = 0.0016

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "sam")


def build_sam_input(image_path, point_px):
    """构造 SAM 输入。

    point_px: (x, y) 像素坐标。社区 SAM 包装的字段名以模型页为准，
    下面是 cbx1/sam-vit-h 的常见口径；若报错，先对照模型页 input schema 修改这里。
    """
    with open(image_path, "rb") as f:
        import base64
        data_uri = "data:image/jpeg;base64," + base64.b64encode(f.read()).decode()
    return {
        "image": data_uri,
        "point_coords": [[int(point_px[0]), int(point_px[1])]],
        "point_labels": [1],  # 1 = 前景点
    }


def download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": "ai-home-probe/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        f.write(r.read())


def mask_to_bbox(mask_path, img_w, img_h):
    """二值 mask → 相对坐标 bbox；同时返回 mask 覆盖面积占比。"""
    im = Image.open(mask_path).convert("L")
    if im.size != (img_w, img_h):
        im = im.resize((img_w, img_h))
    px = im.load()
    xs, ys = [], []
    count = 0
    for y in range(img_h):
        for x in range(img_w):
            if px[x, y] > 128:
                xs.append(x)
                ys.append(y)
                count += 1
    if not xs:
        return None, 0.0
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    return {
        "x": x0 / img_w,
        "y": y0 / img_h,
        "w": (x1 - x0 + 1) / img_w,
        "h": (y1 - y0 + 1) / img_h,
    }, count / (img_w * img_h)


def iou(a, b):
    """两个相对坐标 bbox 的 IoU。"""
    ax1, ay1 = a["x"] + a["w"], a["y"] + a["h"]
    bx1, by1 = b["x"] + b["w"], b["y"] + b["h"]
    ix0, iy0 = max(a["x"], b["x"]), max(a["y"], b["y"])
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    inter = max(0.0, ix1 - ix0) * max(0.0, iy1 - iy0)
    union = a["w"] * a["h"] + b["w"] * b["h"] - inter
    return inter / union if union > 0 else 0.0


def main():
    token = os.environ.get("REPLICATE_API_TOKEN")
    if not token:
        sys.exit("未设置 REPLICATE_API_TOKEN，拒绝运行（key 只从环境变量读）。")
    os.makedirs(OUT_DIR, exist_ok=True)
    client = replicate.Client(api_token=token)

    results = []
    total_usd = 0.0
    for sample in parse_samples_ts():
        for hs in sample["hotspots"]:
            img_path = os.path.join(PROTOTYPE_DIR, sample["image"])
            with Image.open(img_path) as im:
                w, h = im.size
            c = hotspot_center(hs["bbox"])
            point_px = (c["x"] * w, c["y"] * h)

            t0 = time.time()
            try:
                output = client.run(SAM_MODEL, input=build_sam_input(img_path, point_px))
                latency = time.time() - t0
                # 社区模型输出可能是 mask 图 URL（str），也可能是含 mask 字段的 dict
                mask_url = output if isinstance(output, str) else output.get("mask", output)
                if not isinstance(mask_url, str) or not mask_url.startswith("http"):
                    raise RuntimeError(f"无法解析的模型输出: {str(output)[:200]}")
                mask_path = os.path.join(OUT_DIR, f"{hs['id']}_mask.png")
                download(mask_url, mask_path)
                mask_bbox, coverage = mask_to_bbox(mask_path, w, h)
                score = iou(mask_bbox, hs["bbox"]) if mask_bbox else 0.0
                status, err = "ok", ""
            except Exception as e:  # noqa: BLE001 - 探针要记录失败而非中断
                latency = time.time() - t0
                mask_path, mask_bbox, coverage, score = "", None, 0.0, 0.0
                status, err = "error", f"{type(e).__name__}: {e}"

            total_usd += COST_USD_PER_CALL
            rec = {
                "hotspot_id": hs["id"],
                "label": hs["label"],
                "sample_id": sample["id"],
                "center_rel": {"x": round(c["x"], 4), "y": round(c["y"], 4)},
                "center_px": [int(point_px[0]), int(point_px[1])],
                "image_size": [w, h],
                "preset_bbox": hs["bbox"],
                "status": status,
                "error": err,
                "latency_s": round(latency, 2),
                "mask_path": os.path.relpath(mask_path, OUT_DIR) if mask_path else "",
                "mask_bbox_rel": mask_bbox,
                "mask_coverage": round(coverage, 4),
                "iou_vs_preset": round(score, 4),
                "est_cost_usd": COST_USD_PER_CALL,
            }
            results.append(rec)
            print(f"{hs['id']}: status={status} iou={score:.3f} "
                  f"latency={latency:.1f}s err={err[:80]}")

    out_path = os.path.join(OUT_DIR, "sam_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({
            "model": SAM_MODEL,
            "n": len(results),
            "ok": sum(1 for r in results if r["status"] == "ok"),
            "mean_iou": round(sum(r["iou_vs_preset"] for r in results) / len(results), 4),
            "mean_latency_s": round(sum(r["latency_s"] for r in results) / len(results), 2),
            "est_total_cost_usd": round(total_usd, 4),
            "est_total_cost_cny": round(total_usd * 7.2, 2),
            "results": results,
        }, f, ensure_ascii=False, indent=2)
    print(f"\n完成：{out_path}，预估总费用 ${total_usd:.4f}（约 ¥{total_usd * 7.2:.2f}）")


if __name__ == "__main__":
    main()
