# 「AI改我家」Phase 1 AI 探针

小额验证：花 <¥10，用 24 组固定样例先验证真实 AI 行不行，再决定 Phase 1 用哪家。
**只写代码、不调用 API、不注册账号**——运行需要你自己申请 key（见下）。

## 目录

| 文件 | 说明 |
|---|---|
| `probe_cases.py` | 公共模块：解析 `lib/samples.ts`（4 图 8 热点）、构建 24 组样例、生成评分表 |
| `sam_probe.py` | SAM 点选分割探针：8 热点中心点 → Replicate SAM → 存 mask → 与预置 bbox 算 IoU |
| `edit_probe_seedream.py` | Seedream 改图探针（主链路）：24 组 + 8 组 mask A/B 对照 |
| `edit_probe_gemini.py` | Gemini 改图探针（备链路，免费额度内）：同样 24 组 |
| `score.csv` | 人工评分表模板（56 行：seedream 24 + mask 对照 8 + gemini 24） |
| `results/` | 输出目录：`sam/` `seedream/` `gemini/`（跑完才有内容） |

## 0. 准备

```bash
pip install Pillow replicate
```

三个 key **只从环境变量读**，绝不写进代码或文档：

| 环境变量 | 用途 | 去哪申请 |
|---|---|---|
| `REPLICATE_API_TOKEN` | SAM 点选分割（`sam_probe.py`） | Replicate 官网，GitHub 登录，按量 billing，需外币支付方式 |
| `ARK_API_KEY` | Seedream 改图（`edit_probe_seedream.py`） | 火山引擎，开通火山方舟 Seedream 模型调用（个人实名即可） |
| `GEMINI_API_KEY` | Gemini 改图（`edit_probe_gemini.py`，免费额度） | Google AI Studio |

```bash
export REPLICATE_API_TOKEN=...   # 填你自己的，下面两行同理
export ARK_API_KEY=...
export GEMINI_API_KEY=...
```

可选覆盖模型（不设就用默认值，首次运行前建议核对官方文档的模型 ID / input schema）：

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `REPLICATE_SAM_MODEL` | `cbx1/sam-vit-h` | 社区 SAM，input schema 以 Replicate 模型页为准 |
| `SEEDREAM_MODEL` | `seedream-5-0` | 以火山方舟控制台实际模型 ID 为准 |
| `GEMINI_MODEL` | `gemini-2.5-flash-image` | 二代；一代 2026-10-02 退役 |

## 1. 运行步骤（按顺序）

```bash
cd prototype/probe

# ① 自检：解析 samples.ts 是否正常（无网络，可直接跑）
python3 probe_cases.py

# ② SAM 探针：8 个热点 → mask → IoU（约 8 次调用）
python3 sam_probe.py
# 输出：results/sam/<hotspot>_mask.png + results/sam/sam_results.json

# ③ Seedream 探针：24 组 + 8 组 mask A/B（约 32 张）
python3 edit_probe_seedream.py
# 输出：results/seedream/E*.jpg + manifest.json
# 如需关闭 mask A/B：python3 edit_probe_seedream.py --no-mask-ab

# ④ Gemini 探针：同样 24 组（免费额度内，约 500 次/天上限）
python3 edit_probe_gemini.py
# 输出：results/gemini/E*.png + manifest.json

# ⑤ 人工评分：打开 score.csv，对 results/seedream/ 和 results/gemini/ 逐张打分（1–5）
```

## 2. 费用预估（人民币）

| 项目 | 数量 | 单价 | 小计 |
|---|---|---|---|
| SAM（Replicate） | 8 次 | ~¥0.012 | ¥0.10 |
| Seedream 改图 | 32 张 | ¥0.22 | ¥7.04 |
| Gemini 改图 | 24 张 | ¥0（免费额度） | ¥0 |
| **合计** | | | **< ¥10** |

`sam_results.json` / `manifest.json` 里有每轮的实际延迟与预估费用，跑完对照账单即可。

## 3. 判定标准

### Seedream 是否达标（主链路去留）

按 `score.csv` 的人工评分（每维度 1–5 分）：

- **达标**：③中文理解 与 ④整体观感 的平均分 ≥ 3.5，**且** ①未选区域结构保持 ≥ 4
- **不达标**：加测 gpt-image-1-mini（mask 原生支持最好，约 ¥0.19/张），探针脚本结构复用本目录即可

### Seedream 原生 mask 是否生效（探针核心问题之一）

`edit_probe_seedream.py` 默认对每热点第 1 条快捷指令多跑一组传 mask 版（`E01-mask` 等 8 组）：

1. 若 API 直接报错 → 不支持 mask 通道，记结论，后续走「参考图 + 提示词」路线。
2. 若接受请求 → 对比同名样例有/无 mask 的 ① 分：
   - 传 mask 版 ① 分显著更高 → mask 生效，主链路采用「mask + 提示词」。
   - 两版 ① 分无差异 → mask 未生效（可能被忽略），按不支持处理。

### SAM 是否可用

看 `results/sam/sam_results.json` 的 `mean_iou`：

- IoU ≥ 0.5 视为点选分割可用（中心点能圈住目标对象）。
- 明显偏低时，检查：① Replicate 模型 input schema 是否对（坐标口径）② 换 `sepal/sam-embeddings` 混合路线（备选）。

## 4. 安全与约束

- 三个 key 只从环境变量读取；`results/` 下的 manifest 只记费用与延迟，**不记任何 key**。
- `score.csv` 请用 UTF-8（含 BOM，已生成）打开，Excel 可直接编辑。
- 探针样例固定（24 组），复测时用同一批，保证结论可比。
- SAM 3 是研究许可、不可商用——探针与 Phase 1 只用 SAM 1/2 系（Apache 2.0）。
