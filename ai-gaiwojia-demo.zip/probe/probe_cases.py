#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
「AI改我家」Phase 1 探针 - 公共样例模块。

职责：
  1. 解析 prototype/lib/samples.ts，得到 4 张样板图 + 8 个热点的定义
     （bbox 为相对坐标 0~1，与前端保持同一口径）。
  2. 构建 24 组改图探针样例：8 热点 × 2 条快捷指令（E01-E16）
     + 8 条自由中文指令（E17-E24，中文口语风格，与快捷指令不重复）。
  3. 生成人工评分表模板 score.csv。

本模块不做任何网络调用。API key 由各探针脚本从环境变量读取，
绝不写死在本文件或任何探针代码中。
"""

import csv
import json
import os
import re
import sys

# samples.ts 位置：本文件在 prototype/probe/ 下，往上两级是 prototype/
PROTOTYPE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SAMPLES_TS = os.path.join(PROTOTYPE_DIR, "lib", "samples.ts")
SAMPLES_IMG_DIR = os.path.join(PROTOTYPE_DIR, "public", "samples")


def parse_samples_ts(path=SAMPLES_TS):
    """解析 samples.ts，返回 sample 列表。

    每个 sample: {id, image(相对 prototype 的路径), hotspots: [
      {id, label, bbox{x,y,w,h}, instructions:[text, ...]}]}
    """
    with open(path, encoding="utf-8") as f:
        src = f.read()

    samples = []
    sample_iter = list(re.finditer(r"id:\s*'(room-[a-d])'", src))
    for si, sm in enumerate(sample_iter):
        span_end = sample_iter[si + 1].start() if si + 1 < len(sample_iter) else len(src)
        block = src[sm.start():span_end]
        sample_id = sm.group(1)

        img_m = re.search(r"image:\s*'(/samples/(room-[a-d]\.jpg))'", block)
        if not img_m:
            raise ValueError(f"sample {sample_id}: 找不到 image 定义")
        image_rel = os.path.join("public", "samples", img_m.group(2))

        hotspots = []
        hs_iter = list(re.finditer(r"id:\s*'(room-[a-d]-[a-z]+)'", block))
        for hi, hm in enumerate(hs_iter):
            hs_end = hs_iter[hi + 1].start() if hi + 1 < len(hs_iter) else len(block)
            # hs_iter 在 block 上匹配，起止已是 block 相对偏移，直接切片
            hs_block = block[hm.start():hs_end]
            hs_id = hm.group(1)

            label_m = re.search(r"label:\s*'([^']+)'", hs_block)
            bbox_m = re.search(
                r"bbox:\s*\{\s*x:\s*([\d.]+),\s*y:\s*([\d.]+),"
                r"\s*w:\s*([\d.]+),\s*h:\s*([\d.]+)\s*\}", hs_block)
            if not (label_m and bbox_m):
                raise ValueError(f"hotspot {hs_id}: 找不到 label 或 bbox")
            instructions = re.findall(r"text:\s*'([^']+)'", hs_block)
            if not instructions:
                raise ValueError(f"hotspot {hs_id}: 找不到快捷指令")

            hotspots.append({
                "id": hs_id,
                "label": label_m.group(1),
                "bbox": {
                    "x": float(bbox_m.group(1)),
                    "y": float(bbox_m.group(2)),
                    "w": float(bbox_m.group(3)),
                    "h": float(bbox_m.group(4)),
                },
                "instructions": instructions,
            })

        if len(hotspots) != 2:
            raise ValueError(f"sample {sample_id}: 期望 2 个热点，实际 {len(hotspots)} 个")
        samples.append({"id": sample_id, "image": image_rel, "hotspots": hotspots})

    if len(samples) != 4:
        raise ValueError(f"期望 4 张样板图，实际 {len(samples)} 张")
    return samples


# 8 条自由中文指令（每热点 1 条，中文口语风格，与快捷指令不重复）。
# key 为 hotspot id。
FREE_INSTRUCTIONS = {
    "room-a-sofa": "沙发换个奶油色系的，坐起来看着软一点",
    "room-a-tvcabinet": "电视柜换个深胡桃木色的，要有质感",
    "room-b-table": "茶几换个小一点的圆几，边角别太锋利",
    "room-b-curtain": "窗帘换遮光好一点的深色，睡觉不透光",
    "room-c-rug": "地毯换个耐脏的深灰色，家里有狗",
    "room-c-lamp": "落地灯换个暖光的，晚上看书用",
    "room-d-chair": "单人椅换个坐着舒服的懒人沙发款",
    "room-d-art": "挂画换个有山水意境的，看着安静点",
}

# 改图提示词模板：中文指令 + 明确约束（只改指定对象、其余不动、写实风格）。
PROMPT_TEMPLATE = (
    "室内装修效果图局部修改：{instruction}。"
    "只修改图中的{label}，其余墙面、地面、家具、光影和整体构图保持原样不动。"
    "写实摄影风格，光线自然，高分辨率。"
)


def build_edit_cases(samples=None):
    """构建 24 组改图探针样例，返回 case 列表。

    case: {case_id, sample_id, image(相对 prototype 路径), hotspot_id, label,
           kind: 'quick'|'free', instruction, prompt}
    """
    samples = samples or parse_samples_ts()
    cases = []
    n = 0
    for sample in samples:
        for hs in sample["hotspots"]:
            for inst in hs["instructions"][:2]:  # 每热点 2 条快捷指令
                n += 1
                cases.append({
                    "case_id": f"E{n:02d}",
                    "sample_id": sample["id"],
                    "image": hs_image(sample),
                    "hotspot_id": hs["id"],
                    "label": hs["label"],
                    "kind": "quick",
                    "instruction": inst,
                    "prompt": PROMPT_TEMPLATE.format(instruction=inst, label=hs["label"]),
                })
    for sample in samples:
        for hs in sample["hotspots"]:
            n += 1
            inst = FREE_INSTRUCTIONS[hs["id"]]
            cases.append({
                "case_id": f"E{n:02d}",
                "sample_id": sample["id"],
                "image": hs_image(sample),
                "hotspot_id": hs["id"],
                "label": hs["label"],
                "kind": "free",
                "instruction": inst,
                "prompt": PROMPT_TEMPLATE.format(instruction=inst, label=hs["label"]),
            })
    assert len(cases) == 24, f"期望 24 组样例，实际 {len(cases)} 组"
    return cases


def hs_image(sample):
    return sample["image"]


def hotspot_center(bbox):
    """bbox(相对坐标) → 中心点(相对坐标)，供 SAM 点选探针使用。"""
    return {
        "x": bbox["x"] + bbox["w"] / 2.0,
        "y": bbox["y"] + bbox["h"] / 2.0,
    }


def mask_ab_cases():
    """Seedream mask A/B 对比的 8 组：每热点取第 1 条快捷指令样例。

    返回 [(case, ...)]，供 edit_probe_seedream.py --mask-ab 使用。
    判定 mask 是否生效：对比同一 case 有/无 mask 时的人工评分 ①
    （未选区域结构保持）。
    """
    cases = build_edit_cases()
    return [c for c in cases if c["kind"] == "quick" and c["case_id"] in
            {f"E{i:02d}" for i in range(1, 16, 2)}]


SCORE_HEADERS = ["样例编号", "链路", "样板", "对象", "指令",
                 "①未选区域结构保持(1-5)", "②指令遵循度(1-5)",
                 "③中文理解(1-5)", "④整体观感(1-5)", "备注"]


def write_score_csv(path, include_mask_ab=True):
    """生成人工评分表模板（含 Seedream / Gemini 各 24 行，
    可选含 Seedream mask A/B 的 8 行对照）。"""
    cases = build_edit_cases()
    ab = {c["case_id"] for c in mask_ab_cases()} if include_mask_ab else set()
    rows = []
    for c in cases:
        rows.append([c["case_id"], "seedream", c["sample_id"],
                     c["label"], c["instruction"], "", "", "", "", ""])
        if c["case_id"] in ab:
            rows.append([c["case_id"] + "-mask", "seedream(mask对照)",
                         c["sample_id"], c["label"], c["instruction"],
                         "", "", "", "",
                         "同一指令无 mask 版的对照组，对比①分"])
    for c in cases:
        rows.append([c["case_id"], "gemini", c["sample_id"],
                     c["label"], c["instruction"], "", "", "", "", ""])
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(SCORE_HEADERS)
        w.writerows(rows)
    return len(rows)


def main():
    samples = parse_samples_ts()
    print(f"样板图: {len(samples)} 张")
    total_hs = sum(len(s["hotspots"]) for s in samples)
    print(f"热点: {total_hs} 个")
    for s in samples:
        for hs in s["hotspots"]:
            c = hotspot_center(hs["bbox"])
            print(f"  {hs['id']} ({hs['label']}): "
                  f"bbox={hs['bbox']} center=({c['x']:.3f}, {c['y']:.3f}) "
                  f"指令={hs['instructions']}")
    cases = build_edit_cases(samples)
    print(f"改图样例: {len(cases)} 组")
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "score.csv")
    n = write_score_csv(out)
    print(f"评分表已生成: {out}（{n} 行数据）")


if __name__ == "__main__":
    sys.exit(main())
