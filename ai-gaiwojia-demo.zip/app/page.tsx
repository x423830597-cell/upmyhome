'use client';

import { useCallback, useEffect, useRef, useState, type MouseEvent as ReactMouseEvent } from 'react';
import { SAMPLES, type Sample, type Hotspot } from '@/lib/samples';
import { POINTS_PER_EDIT } from '@/lib/constants';

interface EditJob {
  id: string;
  status: string;
  points_cost: number;
  error_class: string | null;
  result_uri: string | null;
  latency_ms: number | null;
}

interface LedgerEntry {
  id: number;
  delta: number;
  reason: string;
  job_id: string | null;
  created_at: string;
}

interface DemoEvent {
  id: number;
  name: string;
  ts: string;
  job_id: string | null;
  props: Record<string, unknown> | null;
}

type Step = 'pick' | 'edit' | 'compare';

type SelectMode = 'sample' | 'upload';

/** 上传照片的点击点选模式：没有预置热点/快捷指令，提供通用快捷指令 */
const POINT_QUICK = ['换成浅色布艺', '换成胡桃木色', '改成奶油风', '换成深灰色'];

interface PointSelection {
  x: number;
  y: number;
  label: string;
  bbox: { x: number; y: number; w: number; h: number };
  maskUri: string | null;
  costCny: number | null;
}

const REASON_LABEL: Record<string, string> = {
  grant_new_session: '新会话赠送',
  charge: 'AI 修改扣点',
  refund: '失败退款',
};

const STATUS_LABEL: Record<string, string> = {
  created: '已创建',
  charged: '已扣点 · 排队中',
  processing: '生成中…',
  succeeded: '生成成功',
  failed: '生成失败',
  refunded: '已失败 · 点数已退回',
};

async function api(path: string, init?: RequestInit) {
  const res = await fetch(path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.message || data.error || `请求失败（${res.status}）`) as Error & {
      code?: string;
      status?: number;
    };
    err.code = data.error;
    err.status = res.status;
    throw err;
  }
  return data;
}

export default function Home() {
  const [sessionId, setSessionId] = useState<string>('');
  const [projectId, setProjectId] = useState<string>('');
  const [balance, setBalance] = useState<number>(0);
  const [step, setStep] = useState<Step>('pick');
  const [sample, setSample] = useState<Sample | null>(null);
  const [baseImage, setBaseImage] = useState<string>('');
  const [baseLabel, setBaseLabel] = useState<string>(''); // 再改一次时标注
  const [assetId, setAssetId] = useState<string>('');
  const [hotspot, setHotspot] = useState<Hotspot | null>(null);
  const [selectionId, setSelectionId] = useState<string>('');
  const [mode, setMode] = useState<SelectMode>('sample');
  const [uploading, setUploading] = useState(false);
  const [pointSel, setPointSel] = useState<PointSelection | null>(null);
  const [samSelecting, setSamSelecting] = useState(false);
  const [instruction, setInstruction] = useState<string>('');
  const [promptType, setPromptType] = useState<'quick' | 'text'>('text');
  const [showConfirm, setShowConfirm] = useState(false);
  const [job, setJob] = useState<EditJob | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [comparePos, setComparePos] = useState(50);
  const [compareFired, setCompareFired] = useState(false);
  const [showLedger, setShowLedger] = useState(false);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [showEvents, setShowEvents] = useState(false);
  const [events, setEvents] = useState<DemoEvent[]>([]);
  const [notice, setNotice] = useState<string>('');
  const [forceFail, setForceFail] = useState<'off' | 'error' | 'timeout'>('off');
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fireEvent = useCallback(
    async (name: string, extra?: { project_id?: string | null; job_id?: string | null; props?: Record<string, unknown> }) => {
      if (!sessionId) return;
      try {
        await api('/api/events', {
          method: 'POST',
          body: JSON.stringify({ name, session_id: sessionId, ...extra }),
        });
      } catch {
        /* 埋点失败不阻断主流程 */
      }
    },
    [sessionId]
  );

  const refreshLedger = useCallback(async () => {
    if (!sessionId) return;
    const data = await api(`/api/points/ledger?session_id=${sessionId}`);
    setBalance(data.balance);
    setLedger(data.entries);
  }, [sessionId]);

  const refreshEvents = useCallback(async () => {
    if (!sessionId) return;
    const data = await api(`/api/events?session_id=${sessionId}`);
    setEvents(data.events);
  }, [sessionId]);

  const initSession = useCallback(async (existingSession?: string) => {
    const data = await api('/api/projects', {
      method: 'POST',
      body: JSON.stringify({ title: '演示项目', session_id: existingSession }),
    });
    setSessionId(data.session_id);
    setProjectId(data.project.id);
    setBalance(data.balance);
    localStorage.setItem('ai-home-demo-session', data.session_id);
    if (data.granted) setNotice('新会话已创建，获赠 30 点演示点数。');
  }, []);

  // 首次进入：恢复或新建会话；若有未完成的任务则续轮询
  useEffect(() => {
    const saved = localStorage.getItem('ai-home-demo-session');
    initSession(saved ?? undefined)
      .then(async () => {
        const pendingJob = localStorage.getItem('ai-home-demo-job');
        if (!pendingJob) return;
        try {
          const sid = localStorage.getItem('ai-home-demo-session');
          const data = await api(`/api/edit-jobs/${pendingJob}?session_id=${sid}`);
          const st = data.job?.status;
          if (st === 'succeeded' || st === 'refunded') {
            localStorage.removeItem('ai-home-demo-job');
            return;
          }
          if (st === 'charged' || st === 'processing' || st === 'failed') {
            setJob(data.job);
            if (typeof data.balance === 'number') setBalance(data.balance);
            pollJob(pendingJob, sid ?? undefined);
            setNotice('已恢复上次未完成的生成任务，继续等待结果…');
          } else {
            localStorage.removeItem('ai-home-demo-job');
          }
        } catch {
          /* 恢复失败则放弃，不阻断 */
        }
      })
      .catch(() => setNotice('服务连接失败，请确认开发服务器已启动。'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  const clearPendingJob = () => {
    try {
      localStorage.removeItem('ai-home-demo-job');
    } catch {
      /* 忽略 */
    }
  };

  const chooseSample = async (s: Sample) => {
    try {
      const data = await api('/api/assets', {
        method: 'POST',
        body: JSON.stringify({ project_id: projectId, session_id: sessionId, kind: 'sample', uri: s.image }),
      });
      setSample(s);
      setMode('sample');
      setPointSel(null);
      setBaseImage(s.image);
      setBaseLabel('样板图');
      setAssetId(data.asset.id);
      setHotspot(null);
      setSelectionId('');
      setInstruction('');
      setJob(null);
      clearPendingJob();
      setComparePos(50);
      setCompareFired(false);
      setStep('edit');
    } catch {
      setNotice('样板加载失败，请重试。');
    }
  };

  const clickHotspot = async (h: Hotspot) => {
    if (hotspot?.id === h.id) {
      // 再次点击取消选中
      setHotspot(null);
      setSelectionId('');
      setInstruction('');
      return;
    }
    try {
      const data = await api('/api/selections', {
        method: 'POST',
        body: JSON.stringify({
          asset_id: assetId,
          session_id: sessionId,
          hotspot_id: h.id,
          project_id: projectId,
        }),
      });
      setHotspot(h);
      setSelectionId(data.selection.id);
      setInstruction('');
    } catch {
      setNotice('选区暂时不可用，未扣除点数。请重新选择一个高亮区域。');
    }
  };

  /** 上传自家照片：走 /api/uploads，之后进入点击坐标点选模式 */
  const chooseUpload = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setNotice('请选择图片文件（JPG/PNG/WebP）。');
      return;
    }
    setUploading(true);
    setNotice('');
    try {
      // 注意：multipart 上传不能走 api() 助手（它会强制 application/json），这里直接 fetch
      const form = new FormData();
      form.append('file', file);
      form.append('project_id', projectId);
      form.append('session_id', sessionId);
      const res = await fetch('/api/uploads', { method: 'POST', body: form });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `上传失败（${res.status}）`);
      setMode('upload');
      setSample(null);
      setBaseImage(data.asset.uri);
      setBaseLabel('上传的照片');
      setAssetId(data.asset.id);
      setHotspot(null);
      setPointSel(null);
      setSelectionId('');
      setInstruction('');
      setJob(null);
      clearPendingJob();
      setComparePos(50);
      setCompareFired(false);
      setStep('edit');
      setNotice('照片上传成功。点击照片中的家具，AI 会分割出它的轮廓（需配置真实 AI Key）。');
    } catch (e) {
      setNotice(e instanceof Error ? e.message : '上传失败，请重试。');
    } finally {
      setUploading(false);
    }
  };

  /** 点击坐标点选：相对坐标 0–1 → /api/selections point 路径（真实 SAM） */
  const selectPoint = async (x: number, y: number) => {
    setSamSelecting(true);
    setNotice('');
    try {
      const data = await api('/api/selections', {
        method: 'POST',
        body: JSON.stringify({
          asset_id: assetId,
          session_id: sessionId,
          point: { x, y },
          project_id: projectId,
        }),
      });
      const s = data.selection;
      setPointSel({
        x,
        y,
        label: s.label,
        bbox: s.bbox,
        maskUri: s.mask_uri,
        costCny: s.cost_cny,
      });
      setSelectionId(s.id);
      setInstruction('');
      setNotice(
        `已选中：${s.label}（AI 分割${typeof s.cost_cny === 'number' ? `，约 ¥${s.cost_cny}` : ''}）。再次点击框内可取消。`
      );
    } catch (e) {
      // mock 下后端返回 400（如"mock 不支持坐标点选…"），或 key 缺失时 502；如实展示，不吞错
      setNotice(e instanceof Error ? e.message : '选区暂时不可用，未扣除点数。');
    } finally {
      setSamSelecting(false);
    }
  };

  const onCanvasClick = (e: ReactMouseEvent<HTMLDivElement>) => {
    if (samSelecting) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    if (x < 0 || x > 1 || y < 0 || y > 1) return;
    // 点击已选框内 → 取消选中；否则重新点选
    const b = pointSel?.bbox;
    if (b && x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) {
      setPointSel(null);
      setSelectionId('');
      setInstruction('');
      return;
    }
    void selectPoint(x, y);
  };

  const pickQuick = (text: string) => {
    setInstruction(text);
    setPromptType('quick');
  };

  const onTextChange = (v: string) => {
    setInstruction(v);
    setPromptType('text');
  };

  const handleSubmit = () => {
    const selectedLabel = hotspot?.label ?? pointSel?.label;
    if (!selectedLabel || !selectionId) {
      setNotice('还没有选择要修改的对象，无法提交。点数未扣除。下一步：点击图片选中一个对象。');
      return;
    }
    if ([...instruction.trim()].length < 1) {
      setNotice('修改指令是空的，无法提交。点数未扣除。下一步：输入 1–200 字的修改描述，或点选一条快捷指令。');
      return;
    }
    setShowConfirm(true);
  };

  const stopPoll = () => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  };

  const confirmSubmit = async () => {
    setShowConfirm(false);
    setSubmitting(true);
    setNotice('');
    try {
      const data = await api('/api/edit-jobs', {
        method: 'POST',
        body: JSON.stringify({
          selection_id: selectionId,
          session_id: sessionId,
          // 样板模式传真实 hotspot id；点击点选模式传 'point' 占位（真实链路 worker 只用 selection，不用它）
          hotspot_id: hotspot?.id ?? 'point',
          prompt: instruction.trim(),
          prompt_type: promptType,
          idempotency_key: crypto.randomUUID(),
          force_fail: forceFail,
        }),
      });
      if (data.deduped) setNotice('该任务已在处理中，未重复扣点。');
      setBalance(data.balance);
      setJob(data.job);
      try {
        localStorage.setItem('ai-home-demo-job', data.job.id);
      } catch {
        /* 忽略存储失败 */
      }
      pollJob(data.job.id);
    } catch (e) {
      const err = e as Error & { code?: string };
      if (err.code === 'insufficient_points') {
        setNotice(err.message + '（演示阶段不提供充值，可点击右上角「新会话」重新获得 30 点。）');
      } else {
        setNotice(err.message);
      }
      await refreshLedger();
    } finally {
      setSubmitting(false);
      setForceFail('off'); // 演示开关一次有效
    }
  };

  const pollJob = (jobId: string, sid?: string) => {
    stopPoll();
    const useSid = sid ?? sessionId;
    pollRef.current = setInterval(async () => {
      try {
        const data = await api(`/api/edit-jobs/${jobId}?session_id=${useSid}`);
        setJob(data.job);
        if (typeof data.balance === 'number') setBalance(data.balance);
        if (data.job.status === 'succeeded') {
          stopPoll();
          clearPendingJob();
          setStep('compare');
          setNotice('生成成功！拖动滑杆对比前后效果。');
        } else if (data.job.status === 'refunded') {
          stopPoll();
          clearPendingJob();
          await refreshLedger();
          setNotice(
            `生成失败了（${data.job.error_class === 'timeout' ? '生成超时' : '模拟服务异常'}）。已扣除的 ${data.job.points_cost} 点已自动退回，当前余额 ${data.balance ?? ''} 点。下一步：换一条指令再试一次，或重新选择对象。`
          );
        } else if (data.job.status === 'failed') {
          setNotice('生成失败，正在自动退点（几秒内完成），请稍候…');
        }
      } catch {
        /* 轮询失败保持当前状态，下次继续 */
      }
    }, 1000);
  };

  const onCompareMove = (v: number) => {
    setComparePos(v);
    if (!compareFired && job) {
      setCompareFired(true);
      fireEvent('compare_used', { job_id: job.id, props: { job_id: job.id } });
    }
  };

  const savePng = () => {
    if (!job?.result_uri) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0);
      // 演示水印
      const fontSize = Math.round(canvas.width / 18);
      ctx.font = `bold ${fontSize}px sans-serif`;
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.textAlign = 'center';
      const label = '演示模式 DEMO · 非真实生成';
      ctx.fillText(label, canvas.width / 2, canvas.height - fontSize);
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.fillText(label, canvas.width / 2, canvas.height - fontSize - 2);
      const a = document.createElement('a');
      a.download = `ai-home-demo-${job.id.slice(0, 8)}.png`;
      a.href = canvas.toDataURL('image/png');
      a.click();
    };
    img.onerror = () => setNotice('图片保存失败，请稍后重试。');
    img.src = job.result_uri;
  };

  const reEdit = async () => {
    if (!job?.result_uri) return;
    await fireEvent('second_edit_started', { job_id: job.id, props: { from_job_id: job.id } });
    try {
      const data = await api('/api/assets', {
        method: 'POST',
        body: JSON.stringify({ project_id: projectId, session_id: sessionId, kind: 'edit_result', uri: job.result_uri }),
      });
      setBaseImage(job.result_uri);
      setBaseLabel('上一版结果');
      setAssetId(data.asset.id);
      setHotspot(null);
      setPointSel(null);
      setSelectionId('');
      setInstruction('');
      setJob(null);
      clearPendingJob();
      setComparePos(50);
      setCompareFired(false);
      setStep('edit');
      setNotice('已基于上一版结果开始第二次编辑：重新点选对象即可。');
    } catch {
      setNotice('进入再次编辑失败，请重试。');
    }
  };

  const newSession = async () => {
    stopPoll();
    localStorage.removeItem('ai-home-demo-session');
    clearPendingJob();
    setStep('pick');
    setSample(null);
    setMode('sample');
    setBaseImage('');
    setUploading(false);
    setPointSel(null);
    setSamSelecting(false);
    setHotspot(null);
    setSelectionId('');
    setInstruction('');
    setJob(null);
    setCompareFired(false);
    await initSession();
  };

  const openLedger = async () => {
    await refreshLedger();
    setShowLedger(true);
  };

  const openEvents = async () => {
    await refreshEvents();
    setShowEvents(true);
  };

  const jobRunning = job && ['created', 'charged', 'processing'].includes(job.status);

  return (
    <div className="page">
      <div className="demo-ribbon">演示模式 DEMO · 所有结果为预生成模拟，非实时 AI 生成 · 点数为演示点数</div>

      <header className="topbar">
        <div className="brand">AI改我家 <span className="phase">Phase 0 原型</span></div>
        <div className="topbar-right">
          <span className="balance" title="演示点数余额">✨ {balance} 点</span>
          <button className="btn ghost" onClick={openLedger}>流水</button>
          <button className="btn ghost" onClick={openEvents}>埋点</button>
          <button className="btn ghost" onClick={newSession}>新会话</button>
        </div>
      </header>

      {notice && (
        <div className="notice" role="status">
          {notice}
          <button className="notice-close" onClick={() => setNotice('')} aria-label="关闭提示">×</button>
        </div>
      )}

      <main className="main">
        {step === 'pick' && (
          <section aria-label="选择样板或上传照片">
            <h1>选一张客厅样板图，或上传你家的照片</h1>
            <p className="hint">样板图走预置热点点选；上传的照片走点击坐标 AI 点选（需配置真实 AI Key，mock 模式下不可用）。图片不超过 10MB。</p>
            <div className="sample-grid">
              <label className={`sample-card upload-card${uploading ? ' busy' : ''}`}>
                <input
                  type="file"
                  accept="image/*"
                  className="file-input"
                  disabled={uploading}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    e.target.value = '';
                    if (f) void chooseUpload(f);
                  }}
                  aria-label="上传自家照片"
                />
                <span className="upload-inner">
                  <span className="upload-icon" aria-hidden="true">{uploading ? '⏳' : '📤'}</span>
                  <strong>{uploading ? '上传中…' : '上传自家照片'}</strong>
                  <span className="hint">点击坐标点选模式</span>
                </span>
              </label>
              {SAMPLES.map((s) => (
                <button key={s.id} className="sample-card" onClick={() => chooseSample(s)}>
                  <img src={s.image} alt={s.title} loading="lazy" />
                  <div className="sample-meta">
                    <strong>{s.title}</strong>
                    <span>{s.subtitle}</span>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {(step === 'edit' || step === 'compare') && (sample || mode === 'upload') && (
          <section aria-label="编辑器" className="editor">
            <div className="editor-top">
              <button className="btn ghost" onClick={() => { stopPoll(); setStep('pick'); setJob(null); clearPendingJob(); }}>
                ← 返回
              </button>
              <span className="base-tag">{mode === 'sample' ? `${baseLabel}：${sample?.title}` : baseLabel}</span>
              <span className={`mode-badge ${mode}`}>{mode === 'sample' ? '预置热点模式' : '点击点选模式'}</span>
            </div>

            {step === 'edit' && (
              <>
                {mode === 'sample' && sample ? (
                  <>
                    <div className="canvas-wrap">
                      <img src={baseImage} alt="待编辑的客厅图" className="canvas-img" />
                      <svg className="hotspot-layer" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                        {sample.hotspots.map((h) => (
                          <rect
                            key={h.id}
                            x={h.bbox.x * 100}
                            y={h.bbox.y * 100}
                            width={h.bbox.w * 100}
                            height={h.bbox.h * 100}
                            className={`hotspot-rect ${hotspot?.id === h.id ? 'selected' : ''}`}
                            rx="1.5"
                          />
                        ))}
                      </svg>
                      {sample.hotspots.map((h) => (
                        <button
                          key={h.id}
                          className={`hotspot-btn ${hotspot?.id === h.id ? 'selected' : ''}`}
                          style={{
                            left: `${h.bbox.x * 100}%`,
                            top: `${h.bbox.y * 100}%`,
                            width: `${h.bbox.w * 100}%`,
                            height: `${h.bbox.h * 100}%`,
                          }}
                          onClick={() => clickHotspot(h)}
                          aria-pressed={hotspot?.id === h.id}
                          aria-label={`选择${h.label}`}
                        >
                          <span className="hotspot-tag">{h.label}</span>
                        </button>
                      ))}
                    </div>
                    <p className="hint">
                      {hotspot ? `已选中：${hotspot.label}（再次点击可取消）` : '第一步：点击图片上的高亮区域，选中要修改的家具'}
                    </p>
                  </>
                ) : (
                  <>
                    <div
                      className="canvas-wrap free point-canvas"
                      onClick={onCanvasClick}
                      role="img"
                      aria-label="上传的照片，点击任意家具进行 AI 点选"
                    >
                      <img src={baseImage} alt="上传的待编辑照片" className="canvas-img" draggable={false} />
                      {pointSel?.maskUri && (
                        <img src={pointSel.maskUri} alt="" aria-hidden="true" className="mask-overlay" draggable={false} />
                      )}
                      <svg className="hotspot-layer" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                        {pointSel && (
                          <>
                            <rect
                              x={pointSel.bbox.x * 100}
                              y={pointSel.bbox.y * 100}
                              width={pointSel.bbox.w * 100}
                              height={pointSel.bbox.h * 100}
                              className="hotspot-rect selected"
                              rx="1.5"
                            />
                            <circle cx={pointSel.x * 100} cy={pointSel.y * 100} r="1.4" className="point-dot" />
                          </>
                        )}
                      </svg>
                      {samSelecting && (
                        <div className="selecting-mask">
                          <div className="spinner" aria-hidden="true" />
                        </div>
                      )}
                    </div>
                    <p className="hint">
                      {pointSel
                        ? `已选中：${pointSel.label}（AI 点选，再次点击框内可取消）`
                        : '第一步：点击照片中的家具，AI 会分割出它的轮廓'}
                    </p>
                  </>
                )}

                <div className="prompt-panel">
                  <div className="quick-row" aria-label="快捷指令">
                    {mode === 'sample'
                      ? (hotspot?.instructions ?? []).map((q) => (
                          <button
                            key={q.id}
                            className={`chip ${instruction === q.text ? 'active' : ''}`}
                            onClick={() => pickQuick(q.text)}
                          >
                            {q.text}
                          </button>
                        ))
                      : (pointSel ? POINT_QUICK : []).map((q) => (
                          <button
                            key={q}
                            className={`chip ${instruction === q ? 'active' : ''}`}
                            onClick={() => pickQuick(q)}
                          >
                            {q}
                          </button>
                        ))}
                    {mode === 'sample' && !hotspot && <span className="hint">先选择对象，再使用快捷指令</span>}
                    {mode === 'upload' && !pointSel && <span className="hint">先点击照片选中对象，再使用快捷指令</span>}
                  </div>
                  <label className="field">
                    <span>修改指令（1–200 字）</span>
                    <textarea
                      value={instruction}
                      onChange={(e) => onTextChange(e.target.value.slice(0, 200))}
                      placeholder="例如：换成浅色布艺沙发，宽一点，其他地方不要动"
                      rows={3}
                      maxLength={200}
                    />
                    <span className="counter">{[...instruction].length}/200</span>
                  </label>
                  <button className="btn primary" onClick={handleSubmit} disabled={submitting || !!job}>
                    {submitting ? '提交中…' : jobRunning ? '生成中…' : `✨ AI 修改 · ${POINTS_PER_EDIT} 点`}
                  </button>
                  {!hotspot && !pointSel && <p className="hint warn">还没有选择对象，无法提交（不会扣点）。</p>}
                </div>

                {jobRunning && job && (
                  <div className="job-card" role="status">
                    <div className="spinner" aria-hidden="true" />
                    <div>
                      <strong>任务状态：{STATUS_LABEL[job.status] ?? job.status}</strong>
                      <p className="hint">已预扣 {job.points_cost} 点。排队与生成约需 6 秒，可等待或稍后查看；请勿重复提交。</p>
                    </div>
                  </div>
                )}
                {job && job.status === 'failed' && (
                  <div className="job-card error" role="alert">
                    <strong>生成失败了（{job.error_class === 'timeout' ? '生成超时' : '模拟服务异常'}）。</strong>
                    <p>已扣除的 {job.points_cost} 点将在几秒内自动退回，余额不会减少。下一步：等待退点完成，或换一条指令再试一次。</p>
                  </div>
                )}
              </>
            )}

            {step === 'compare' && job?.result_uri && (
              <div className="compare-wrap">
                <div className="compare-box">
                  <img src={baseImage} alt="修改前" className="compare-img base" />
                  <div
                    className="compare-after"
                    style={{ clipPath: `inset(0 ${100 - comparePos}% 0 0)` }}
                  >
                    <img src={job.result_uri} alt="修改后（演示模拟结果）" className="compare-img" />
                    <span className="demo-badge">演示模式</span>
                  </div>
                  <div className="compare-handle" style={{ left: `${comparePos}%` }} aria-hidden="true" />
                  <span className="compare-label left">修改前</span>
                  <span className="compare-label right">修改后 · 演示</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={comparePos}
                  onChange={(e) => onCompareMove(Number(e.target.value))}
                  aria-label="拖动对比前后效果"
                  className="compare-slider"
                />
                <div className="compare-actions">
                  <button className="btn primary" onClick={reEdit}>再改一次</button>
                  <button className="btn" onClick={savePng}>保存图片（PNG · 演示水印）</button>
                </div>
                <p className="hint">结果为预生成模拟图，仅用于演示交互流程。耗时 {job.latency_ms ? `${(job.latency_ms / 1000).toFixed(1)}s` : '—'} · 实际 AI 成本 ¥0（模拟）</p>
              </div>
            )}
          </section>
        )}
      </main>

      <aside className="demo-panel" aria-label="演示控制">
        <strong>演示控制</strong>
        <label>
          下一次生成：
          <select value={forceFail} onChange={(e) => setForceFail(e.target.value as 'off' | 'error' | 'timeout')}>
            <option value="off">正常生成</option>
            <option value="error">强制失败（演示退点）</option>
            <option value="timeout">强制超时（演示退点）</option>
          </select>
        </label>
        <span className="hint">失败后约 5 秒自动退点，可在「流水」中查看。</span>
      </aside>

      {showConfirm && (
        <div className="modal-mask" onClick={() => setShowConfirm(false)}>
          <div className="modal" role="dialog" aria-modal="true" aria-label="确认扣点" onClick={(e) => e.stopPropagation()}>
            <h2>确认提交 AI 修改</h2>
            <ul className="confirm-list">
              <li>修改对象：{hotspot?.label ?? pointSel?.label}</li>
              {pointSel && typeof pointSel.costCny === 'number' && (
                <li>选区来源：AI 点击点选（约 ¥{pointSel.costCny}）</li>
              )}
              <li>指令：{instruction.trim()}</li>
              <li>本次消耗：<strong>{POINTS_PER_EDIT} 点</strong></li>
              <li>当前余额：{balance} 点（提交后约 {balance - POINTS_PER_EDIT} 点）</li>
              <li className="hint">演示模式：结果为预生成模拟图；生成失败会自动退点。</li>
            </ul>
            <div className="modal-actions">
              <button className="btn" onClick={() => setShowConfirm(false)}>取消</button>
              <button className="btn primary" onClick={confirmSubmit} autoFocus>确认提交 · {POINTS_PER_EDIT} 点</button>
            </div>
          </div>
        </div>
      )}

      {showLedger && (
        <div className="modal-mask" onClick={() => setShowLedger(false)}>
          <div className="modal wide" role="dialog" aria-modal="true" aria-label="点数流水" onClick={(e) => e.stopPropagation()}>
            <h2>点数余额与流水</h2>
            <p className="balance-big">✨ {balance} 点 <span className="hint">（演示点数 · 本阶段不提供充值）</span></p>
            <table className="ledger-table">
              <thead>
                <tr><th>时间</th><th>变动</th><th>原因</th><th>关联任务</th></tr>
              </thead>
              <tbody>
                {ledger.map((e) => (
                  <tr key={e.id}>
                    <td>{new Date(e.created_at).toLocaleString('zh-CN', { hour12: false })}</td>
                    <td className={e.delta >= 0 ? 'pos' : 'neg'}>{e.delta >= 0 ? `+${e.delta}` : e.delta}</td>
                    <td>{REASON_LABEL[e.reason] ?? e.reason}</td>
                    <td className="mono">{e.job_id ? e.job_id.slice(0, 8) : '—'}</td>
                  </tr>
                ))}
                {ledger.length === 0 && <tr><td colSpan={4} className="hint">暂无流水</td></tr>}
              </tbody>
            </table>
            <div className="modal-actions">
              <button className="btn" onClick={() => setShowLedger(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {showEvents && (
        <div className="modal-mask" onClick={() => setShowEvents(false)}>
          <div className="modal wide" role="dialog" aria-modal="true" aria-label="埋点事件" onClick={(e) => e.stopPropagation()}>
            <h2>埋点事件（演示看板）</h2>
            <p className="hint">仅记录事件类型与任务标识，不记录原始图片与完整提示词。</p>
            <table className="ledger-table">
              <thead>
                <tr><th>时间</th><th>事件</th><th>任务</th><th>属性</th></tr>
              </thead>
              <tbody>
                {events.map((e) => (
                  <tr key={e.id}>
                    <td>{new Date(e.ts).toLocaleTimeString('zh-CN', { hour12: false })}</td>
                    <td className="mono">{e.name}</td>
                    <td className="mono">{e.job_id ? e.job_id.slice(0, 8) : '—'}</td>
                    <td className="mono small">{e.props ? JSON.stringify(e.props) : '—'}</td>
                  </tr>
                ))}
                {events.length === 0 && <tr><td colSpan={4} className="hint">暂无事件</td></tr>}
              </tbody>
            </table>
            <div className="modal-actions">
              <button className="btn" onClick={() => setShowEvents(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
