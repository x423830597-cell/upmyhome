import { NextRequest } from 'next/server';
import { getDb, newId, nowIso } from '@/lib/db';
import { recordEvent } from '@/lib/events';
import { selectorAdapter, aiProvider } from '@/lib/adapters';
import { getRealSelectorAdapter, type RealMaskResult } from '@/lib/real_adapters';
import { findHotspot } from '@/lib/samples';

/**
 * POST /api/selections
 * body: { asset_id, session_id, hotspot_id?, point?, project_id? }
 *
 * - hotspot_id：预置样板热点。AI_PROVIDER=mock 时走 MockMask；
 *   真实链路时取该热点 bbox 中心点调点选分割（aliyun=阿里云分割，seedream/gemini=Replicate SAM 已废弃）。
 * - point: {x, y}（0-1 相对坐标）：上传自家照片后的点选，只走真实点选分割；
 *   mock 下返回 400（Mock 只认识预置热点）。
 *
 * 经 SelectorAdapter 确认选区，落库并记录 selection_confirmed。
 * 点选分割成本（阿里云约 ¥0.03/次[待核对]，Replicate SAM 约 ¥0.01/次）在响应 cost_cny
 * 与服务端日志中明示（edit_job.actual_ai_cost 只记改图调用成本，见 README）。
 */
export async function POST(req: NextRequest) {
  const db = getDb();
  const body = await req.json().catch(() => ({}));
  const { asset_id, session_id, hotspot_id, point, project_id } = body;
  if (!asset_id || !session_id || (!hotspot_id && !point)) {
    return Response.json({ error: 'missing asset_id, session_id or hotspot_id/point' }, { status: 400 });
  }
  const asset = db.prepare(`SELECT id, uri FROM asset WHERE id = ?`).get(asset_id) as
    | { id: string; uri: string }
    | undefined;
  if (!asset) {
    return Response.json({ error: 'asset not found' }, { status: 404 });
  }

  const provider = aiProvider();
  let mask: { label: string; bbox: { x: number; y: number; w: number; h: number }; maskUri: string | null };
  let maskSource: string;
  let samCostCny: number | null = null;

  try {
    if (point !== undefined && point !== null) {
      // 坐标点选：只走真实 SAM。
      const { x, y } = point as { x?: unknown; y?: unknown };
      if (typeof x !== 'number' || typeof y !== 'number' || x < 0 || x > 1 || y < 0 || y > 1) {
        return Response.json({ error: 'point 须为 {x, y} 且在 0-1 范围内' }, { status: 400 });
      }
      if (provider === 'mock') {
        return Response.json(
          { error: 'mock 不支持坐标点选：请设置 AI_PROVIDER=aliyun（国内推荐）|seedream|gemini 并配置 key' },
          { status: 400 }
        );
      }
      const real: RealMaskResult = await getRealSelectorAdapter().selectObject(asset.uri, { x, y });
      mask = { label: real.label, bbox: real.bbox, maskUri: real.maskUri };
      maskSource = real.source;
      samCostCny = real.costCny;
      console.log(`[segment] source=${real.source} point=(${x},${y}) cost_cny=${real.costCny} latency_ms=${real.latencyMs}`);
    } else {
      // 预置热点路径
      if (provider === 'mock') {
        const m = await selectorAdapter.selectObject(asset_id, hotspot_id);
        mask = { label: m.label, bbox: m.bbox, maskUri: m.maskUri };
        maskSource = m.source;
      } else {
        const found = findHotspot(hotspot_id);
        if (!found) return Response.json({ error: `unknown hotspot: ${hotspot_id}` }, { status: 400 });
        const b = found.hotspot.bbox;
        const real: RealMaskResult = await getRealSelectorAdapter().selectObject(
          asset.uri,
          { x: b.x + b.w / 2, y: b.y + b.h / 2 },
          found.hotspot.label
        );
        mask = { label: real.label, bbox: real.bbox, maskUri: real.maskUri };
        maskSource = real.source;
        samCostCny = real.costCny;
        console.log(`[segment] source=${real.source} hotspot=${hotspot_id} cost_cny=${real.costCny} latency_ms=${real.latencyMs}`);
      }
    }
  } catch (e) {
    // key 缺失 / SAM 失败：诚实报错，未扣除点数。
    const msg = e instanceof Error ? e.message : String(e);
    return Response.json(
      {
        error: 'mask_unavailable',
        message: `选区暂时不可用，未扣除点数。原因：${msg}`,
      },
      { status: 502 }
    );
  }

  const id = newId();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO selection (id, asset_id, mask_asset_id, label, bbox, created_at) VALUES (?,?,?,?,?,?)`
  ).run(id, asset_id, mask.maskUri, mask.label, JSON.stringify(mask.bbox), ts);

  recordEvent(db, {
    name: 'selection_confirmed',
    session_id,
    project_id: project_id ?? null,
    props: { label: mask.label, mask_source: maskSource, sam_cost_cny: samCostCny },
  });

  return Response.json({
    selection: {
      id,
      asset_id,
      label: mask.label,
      bbox: mask.bbox,
      mask_uri: mask.maskUri,
      mask_source: maskSource,
      cost_cny: samCostCny,
      created_at: ts,
    },
  });
}
