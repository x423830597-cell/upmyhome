import { NextRequest } from 'next/server';
import { getDb } from '@/lib/db';
import { getBalance, listLedger } from '@/lib/ledger';

/** GET /api/points/ledger?session_id= — 余额与流水 */
export async function GET(req: NextRequest) {
  const db = getDb();
  const sessionId = new URL(req.url).searchParams.get('session_id');
  if (!sessionId) {
    return Response.json({ error: 'missing session_id' }, { status: 400 });
  }
  return Response.json({
    session_id: sessionId,
    balance: getBalance(db, sessionId),
    entries: listLedger(db, sessionId),
  });
}
