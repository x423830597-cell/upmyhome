import { NextRequest } from 'next/server';
import { getDb } from '@/lib/db';
import { getBalance } from '@/lib/ledger';
import { createAndChargeJob, getJobByIdemKey, type ForceFailMode } from '@/lib/jobs';
import { POINTS_PER_EDIT } from '@/lib/constants';

/**
 * POST /api/edit-jobs
 * body: { selection_id, session_id, hotspot_id, prompt, prompt_type, idempotency_key, force_fail? }
 * 同一 idempotency_key 只产生一笔 charge；重复提交直接返回原任务。
 */
export async function POST(req: NextRequest) {
  const db = getDb();
  const body = await req.json().catch(() => ({}));
  const { selection_id, session_id, hotspot_id, prompt, prompt_type, idempotency_key } = body;
  const forceFail = (body.force_fail ?? 'off') as ForceFailMode;

  if (!selection_id || !session_id || !hotspot_id || !idempotency_key) {
    return Response.json({ error: 'missing required fields' }, { status: 400 });
  }

  // 幂等：已存在的 key 直接返回原任务（不重复扣点）
  const dup = getJobByIdemKey(db, idempotency_key);
  if (dup) {
    return Response.json({ job: dup, created: false, deduped: true, balance: getBalance(db, session_id) });
  }

  const promptText = typeof prompt === 'string' ? prompt.trim() : '';
  const promptLen = [...promptText].length;
  if (promptLen < 1 || promptLen > 200) {
    return Response.json(
      {
        error: 'invalid_prompt',
        message:
          '修改指令是空的或超过了 200 字，无法提交。点数未扣除。下一步：在文本框输入 1–200 字的修改描述，或点选一条快捷指令。',
      },
      { status: 400 }
    );
  }

  const selection = db.prepare(`SELECT id FROM selection WHERE id = ?`).get(selection_id);
  if (!selection) {
    return Response.json(
      {
        error: 'no_selection',
        message: '还没有选择要修改的对象，无法提交。点数未扣除。下一步：点击图片上的高亮区域选中一个对象。',
      },
      { status: 400 }
    );
  }

  const balance = getBalance(db, session_id);
  if (balance < POINTS_PER_EDIT) {
    return Response.json(
      {
        error: 'insufficient_points',
        message: `本次修改需要 ${POINTS_PER_EDIT} 点，当前余额 ${balance} 点，点数不足。点数未扣除。下一步：点击「新会话」可重新获得 30 点继续体验（演示阶段不提供充值）。`,
        balance,
      },
      { status: 402 }
    );
  }

  const { job, created } = createAndChargeJob(db, {
    selection_id,
    session_id,
    hotspot_id,
    prompt: promptText,
    prompt_type: prompt_type === 'text' ? 'text' : 'quick',
    points_cost: POINTS_PER_EDIT,
    idem_key: idempotency_key,
    force_fail: forceFail,
  });

  return Response.json({ job, created, balance: getBalance(db, session_id) });
}
