import { NextRequest } from 'next/server';
import { getDb } from '@/lib/db';
import { getJob } from '@/lib/jobs';
import { getBalance } from '@/lib/ledger';

/** GET /api/edit-jobs/{id}?session_id= — 轮询任务状态与结果 */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const db = getDb();
  const job = getJob(db, id);
  if (!job) {
    return Response.json({ error: 'job not found' }, { status: 404 });
  }
  const url = new URL(_req.url);
  const sessionId = url.searchParams.get('session_id');
  return Response.json({
    job,
    balance: sessionId ? getBalance(db, sessionId) : undefined,
  });
}
