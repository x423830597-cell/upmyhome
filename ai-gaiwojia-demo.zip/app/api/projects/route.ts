import { NextRequest } from 'next/server';
import { getDb, newId, nowIso } from '@/lib/db';
import { appendLedger, getBalance } from '@/lib/ledger';
import { recordEvent } from '@/lib/events';

const NEW_SESSION_GRANT = 30;

/**
 * POST /api/projects
 * body: { title?, session_id? }
 * 新 session 自动赠送 30 点（reason=grant_new_session）。
 */
export async function POST(req: NextRequest) {
  const db = getDb();
  const body = await req.json().catch(() => ({}));
  let sessionId: string = body.session_id;
  let granted = false;

  if (!sessionId) {
    sessionId = newId();
  }
  const existing = db
    .prepare(`SELECT id FROM point_ledger WHERE session_id = ? LIMIT 1`)
    .get(sessionId);
  if (!existing) {
    appendLedger(db, {
      session_id: sessionId,
      delta: NEW_SESSION_GRANT,
      reason: 'grant_new_session',
      idem_key: `grant:${sessionId}`,
    });
    granted = true;
  }

  const id = newId();
  const ts = nowIso();
  db.prepare(`INSERT INTO project (id, session_id, title, created_at) VALUES (?,?,?,?)`).run(
    id,
    sessionId,
    body.title ?? '演示项目',
    ts
  );
  recordEvent(db, {
    name: 'demo_started',
    session_id: sessionId,
    project_id: id,
    props: { source: 'sample_gallery', viewport: 'web' },
  });

  return Response.json({
    project: { id, session_id: sessionId, title: body.title ?? '演示项目', created_at: ts },
    session_id: sessionId,
    balance: getBalance(db, sessionId),
    granted,
  });
}
