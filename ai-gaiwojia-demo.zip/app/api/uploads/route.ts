import { NextRequest } from 'next/server';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDb, newId, nowIso } from '@/lib/db';
import { recordEvent } from '@/lib/events';

const MAX_BYTES = 10 * 1024 * 1024; // 10MB
const EXT_BY_MIME: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};

/**
 * POST /api/uploads（multipart/form-data）
 * fields: file（图片，必填）, project_id（可选）, session_id（可选）
 *
 * 自用 demo 的“上传自家照片”入口：文件落盘到 public/uploads/<uuid>.<ext>，
 * 登记 asset 行并返回；前端拿到 asset 后即可走 /api/selections 的 point 点选。
 * project_id 缺失但给了 session_id 时自动建一个项目；两者都没有则 400。
 */
export async function POST(req: NextRequest) {
  const db = getDb();
  const form = await req.formData().catch(() => null);
  if (!form) return Response.json({ error: '需要 multipart/form-data' }, { status: 400 });

  const file = form.get('file');
  if (!(file instanceof File)) return Response.json({ error: '缺少 file 字段' }, { status: 400 });
  if (!file.type.startsWith('image/')) {
    return Response.json({ error: `只支持图片上传，当前类型: ${file.type || '未知'}` }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return Response.json({ error: `图片超过 10MB（${(file.size / 1048576).toFixed(1)}MB）` }, { status: 400 });
  }
  const ext = EXT_BY_MIME[file.type] ?? 'jpg';

  let projectId = form.get('project_id');
  const sessionId = form.get('session_id');
  if (typeof projectId !== 'string' || !projectId) {
    if (typeof sessionId !== 'string' || !sessionId) {
      return Response.json({ error: '缺少 project_id 或 session_id' }, { status: 400 });
    }
    projectId = newId();
    db.prepare(`INSERT INTO project (id, session_id, title, created_at) VALUES (?,?,?,?)`).run(
      projectId,
      sessionId,
      '自用上传',
      nowIso()
    );
  }

  const id = newId();
  const uri = `/uploads/${crypto.randomUUID()}.${ext}`;
  const dest = path.join(process.cwd(), 'public', uri);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(await file.arrayBuffer()));

  const ts = nowIso();
  db.prepare(`INSERT INTO asset (id, project_id, kind, uri, width, height, hash, created_at) VALUES (?,?,?,?,?,?,?,?)`).run(
    id,
    projectId,
    'upload',
    uri,
    null,
    null,
    null,
    ts
  );
  if (typeof sessionId === 'string' && sessionId) {
    recordEvent(db, {
      name: 'asset_ready',
      session_id: sessionId,
      project_id: projectId as string,
      props: { kind: 'upload' },
    });
  }

  return Response.json({
    asset: { id, project_id: projectId, kind: 'upload', uri, created_at: ts },
  });
}
