import { NextRequest } from 'next/server';
import { getDb } from '@/lib/db';
import { recordEvent, listEvents, EVENT_NAMES, type EventName } from '@/lib/events';

/** POST /api/events — 埋点采集（仅字典内事件；不记录原始图片/完整提示词/PII） */
export async function POST(req: NextRequest) {
  const db = getDb();
  const body = await req.json().catch(() => ({}));
  const { name, session_id } = body;
  if (!name || !session_id || !(EVENT_NAMES as readonly string[]).includes(name)) {
    return Response.json({ error: 'invalid event name or missing session_id' }, { status: 400 });
  }
  const event = recordEvent(db, {
    name: name as EventName,
    session_id,
    project_id: body.project_id ?? null,
    job_id: body.job_id ?? null,
    props: body.props ?? undefined,
  });
  return Response.json({ event });
}

/** GET /api/events?session_id= — 演示埋点看板 */
export async function GET(req: NextRequest) {
  const db = getDb();
  const sessionId = new URL(req.url).searchParams.get('session_id');
  if (!sessionId) {
    return Response.json({ error: 'missing session_id' }, { status: 400 });
  }
  return Response.json({ events: listEvents(db, sessionId) });
}
