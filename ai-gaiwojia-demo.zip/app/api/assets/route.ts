import { NextRequest } from 'next/server';
import { getDb, newId, nowIso } from '@/lib/db';
import { recordEvent } from '@/lib/events';

/**
 * POST /api/assets
 * body: { project_id, kind, uri, width?, height?, hash?, session_id? }
 */
export async function POST(req: NextRequest) {
  const db = getDb();
  const body = await req.json().catch(() => ({}));
  if (!body.project_id || !body.uri) {
    return Response.json({ error: 'missing project_id or uri' }, { status: 400 });
  }
  const id = newId();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO asset (id, project_id, kind, uri, width, height, hash, created_at) VALUES (?,?,?,?,?,?,?,?)`
  ).run(
    id,
    body.project_id,
    body.kind ?? 'image',
    body.uri,
    body.width ?? null,
    body.height ?? null,
    body.hash ?? null,
    ts
  );
  if (body.session_id) {
    recordEvent(db, {
      name: 'asset_ready',
      session_id: body.session_id,
      project_id: body.project_id,
      props: { kind: body.kind ?? 'image' },
    });
  }
  return Response.json({
    asset: {
      id,
      project_id: body.project_id,
      kind: body.kind ?? 'image',
      uri: body.uri,
      width: body.width ?? null,
      height: body.height ?? null,
      created_at: ts,
    },
  });
}
